﻿import std;

using namespace std;

int main()
{
	int x{ 42 };
	int y{ 84 };
	println(cerr, "x has value {} and y has value {}.", x, y);
}
