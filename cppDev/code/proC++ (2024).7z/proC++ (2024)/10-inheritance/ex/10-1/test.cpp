import hr;

int main()
{
	HR::Person person{ "Otis", "Lowe" };
	HR::Employee employee{ 123, "Otis", "Lowe" };
}
