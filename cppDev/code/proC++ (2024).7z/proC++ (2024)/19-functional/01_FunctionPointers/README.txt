Compile each of the source files in this directory separately.

02_MessageBoxA.cpp only compiles on Windows.