using namespace std;

int main()
{
	/* How to test the SpreadsheetCell class follows later in the chapter. */
}
