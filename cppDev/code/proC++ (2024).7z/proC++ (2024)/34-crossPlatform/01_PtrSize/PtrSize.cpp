import std;

using namespace std;

int main()
{
	int* ptr{ nullptr };
	println("ptr size is {} bytes", sizeof(ptr));
}
