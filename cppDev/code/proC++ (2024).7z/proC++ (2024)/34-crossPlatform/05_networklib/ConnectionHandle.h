
///////////////////////////////////////////////////////////////
//                                                           //
// For this example, this class is kept to the bare minimum. //
//                                                           //
///////////////////////////////////////////////////////////////

class ConnectionHandle
{
};
