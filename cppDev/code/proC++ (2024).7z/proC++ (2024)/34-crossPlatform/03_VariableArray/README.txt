VariableArray.cpp attempts to create a stack-based array using a variable as the size.
This is not a standard C++ feature, although some compilers may allow it.
