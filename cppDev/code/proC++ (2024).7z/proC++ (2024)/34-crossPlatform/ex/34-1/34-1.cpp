import std;

using namespace std;

int main()
{
	println("sizeof(char) = {}", sizeof(char));
	println("sizeof(short) = {}", sizeof(short));
	println("sizeof(int) = {}", sizeof(int));
	println("sizeof(long) = {}", sizeof(long));
	println("sizeof(long long) = {}", sizeof(long long));
}