#include "writeTextCpp.h"
import std;

using namespace std;

void writeTextFromCpp(const char* text)
{
	println("C++ is writing:");
	println("{}", text);
}