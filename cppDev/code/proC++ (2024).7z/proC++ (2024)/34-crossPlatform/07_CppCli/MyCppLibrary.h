#pragma once

using namespace System;

namespace MyCppLibrary
{
	public ref class MyCppRefClass
	{
	public:
		double TripleIt(double value) { return value * 3.0; }
	};
}
