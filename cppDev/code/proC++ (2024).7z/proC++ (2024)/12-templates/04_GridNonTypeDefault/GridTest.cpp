import grid;
import std;

using namespace std;

int main()
{
	Grid<> myIntGrid;
	Grid<int> myGrid;
	Grid<int, 5> anotherGrid;
	Grid<int, 5, 5> aFourthGrid;
}
