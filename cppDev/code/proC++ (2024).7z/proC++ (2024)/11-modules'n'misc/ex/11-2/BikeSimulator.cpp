module simulator;

import std;

using namespace Simulator;
using namespace std;

BikeSimulator::BikeSimulator()
{
	println("BikeSimulator::BikeSimulator()");
}
