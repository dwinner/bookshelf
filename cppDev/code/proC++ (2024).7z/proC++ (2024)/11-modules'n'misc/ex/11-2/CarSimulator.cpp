module simulator;

import std;

using namespace Simulator;
using namespace std;

CarSimulator::CarSimulator()
{
	println("CarSimulator::CarSimulator()");
}
