module math:details;  // math:details implementation partition

double someHelperFunction(double a)
{
	// Implementation omitted...
	return 42;
}
