module math;

import :details;

double Math::superLog(double z, double b)
{
	// Implementation omitted...
	return someHelperFunction(z);
}

double Math::lerchZeta(double lambda, double alpha, double s)
{
	// Implementation omitted...
	return someHelperFunction(s);
}
