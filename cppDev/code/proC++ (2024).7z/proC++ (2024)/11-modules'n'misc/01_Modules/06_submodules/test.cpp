import datamodel.address;

int main()
{
	DataModel::Address a;
}
