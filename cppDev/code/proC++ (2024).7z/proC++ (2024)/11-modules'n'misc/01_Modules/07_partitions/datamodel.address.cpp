module datamodel;  // Not datamodel:address!

import std;

using namespace std;

DataModel::Address::Address()
{
	println("Address::Address()");
}
