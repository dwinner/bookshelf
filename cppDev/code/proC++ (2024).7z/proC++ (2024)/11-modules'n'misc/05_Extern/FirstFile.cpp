import std;

extern int x;

int main()
{
	std::println("{}", x);
}
