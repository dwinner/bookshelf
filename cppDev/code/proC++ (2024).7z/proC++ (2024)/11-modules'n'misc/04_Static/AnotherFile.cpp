import std;

static void f();

void f()
{
	std::println("f");
}
