delete from ezy_course_c4 where course_id=3;
