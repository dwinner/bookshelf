### Code from Manning book - Rust Servers, Services and Apps
