﻿public class Tree
{
    private class Node
    {
        internal int value;
        internal Node lChild;
        internal Node rChild;
        // Nested Class Node other fields and methods.    
    }

    private Node root;
    // Outer Class Tree other fields and methods.
}