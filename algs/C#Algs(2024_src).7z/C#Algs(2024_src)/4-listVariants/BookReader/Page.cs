﻿// BOOK READER
// Chapter 4 (Variants of Lists)
// C# Data Structures and Algorithms, Second Edition

public record Page(string Content);
