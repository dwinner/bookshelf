﻿// USER DETAILS
// Chapter 6 (Dictionaries and Sets)
// C# Data Structures and Algorithms, Second Edition

public record Employee(string FirstName, string LastName, string PhoneNumber);
