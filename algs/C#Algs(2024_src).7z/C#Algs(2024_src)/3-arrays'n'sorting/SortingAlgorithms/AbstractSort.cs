﻿// SORTING ALGORITHMS
// Chapter 3 (Arrays and Sorting)
// C# Data Structures and Algorithms, Second Edition

public abstract class AbstractSort
{
    public abstract void Sort(int[] a);
}
