﻿// CLOSEST PAIR OF POINTS
// Chapter 9 (See in Action)
// C# Data Structures and Algorithms, Second Edition

public record Result(Point P1, Point P2, double Distance);
