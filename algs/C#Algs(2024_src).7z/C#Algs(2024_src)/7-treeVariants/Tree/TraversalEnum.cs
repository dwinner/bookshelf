﻿// BINARY TREE TRAVERSAL
// Chapter 7 (Variants of Trees)
// C# Data Structures and Algorithms, Second Edition

public enum TraversalEnum
{ 
    PreOrder, 
    InOrder, 
    PostOrder 
}