﻿// TREE
// Chapter 7 (Variants of Trees)
// C# Data Structures and Algorithms, Second Edition

public class Tree<T>
{
    public TreeNode<T>? Root { get; set; }
}
