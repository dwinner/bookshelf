﻿// COMPANY STRUCTURE
// Chapter 7 (Variants of Trees)
// C# Data Structures and Algorithms, Second Edition

public record Person(string Name, string Role);
