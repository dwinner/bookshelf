﻿namespace WidgetBoard.ViewModels;

public interface IWidgetViewModel
{
    int Position { get; set; }

    string Type { get; }
}
