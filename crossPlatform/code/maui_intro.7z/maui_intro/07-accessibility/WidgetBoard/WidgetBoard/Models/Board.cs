﻿namespace WidgetBoard.Models;

public class Board
{
    public string Name { get; init; }

    public BaseLayout Layout { get; init; }
}
