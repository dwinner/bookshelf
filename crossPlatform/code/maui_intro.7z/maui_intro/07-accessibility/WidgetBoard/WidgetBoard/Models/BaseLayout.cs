﻿namespace WidgetBoard.Models;

public abstract class BaseLayout
{
}
