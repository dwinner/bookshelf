﻿namespace WidgetBoard;

public enum State
{
    None = 0,
    Loading = 1,
    Loaded = 2,
    Error = 3,
    PermissionError = 4
}
