﻿namespace WidgetBoard.Communications;

public class Forecast
{
	public string Timezone { get; set; }

	public Current Current { get; set; }
}
