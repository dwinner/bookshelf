﻿namespace WidgetBoard.Services;

public partial class MultiPlatformLocationService : ILocationService
{
}
