// +build unit_tests all_tests

package all_test

import "testing"

func TestUnit(t *testing.T) {
	t.Logf("Ran unit test")
}
