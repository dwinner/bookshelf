// +build integration_tests all_tests

package all_test

import "testing"

func TestIntegration(t *testing.T) {
	t.Logf("Ran integration test")
}
