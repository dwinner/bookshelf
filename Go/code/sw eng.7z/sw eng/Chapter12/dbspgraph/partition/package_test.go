package partition

import (
	"testing"

	gc "gopkg.in/check.v1"
)

func Test(t *testing.T) {
	// Run all gocheck test-suites
	gc.TestingT(t)
}
