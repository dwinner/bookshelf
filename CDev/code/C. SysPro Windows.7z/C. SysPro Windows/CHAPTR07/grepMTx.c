/* Chapter 7. grepMTx. INTENTIONALLY DEFECTIVE	 */
/* Parallel grep - Multiple thread version. Boss/worker model */

/* grep pattern files.
	Search one or more files for the pattern.
	The results are listed in the order in which the
	threads complete, not in the order the files are
	on the command line. This is primarily to illustrate
	the non-determinism of thread completion. To obtain
	ordered output, use the technique in Program 8-1. */

/* Be certain to define _MT in Environment.h
	or use the build...settings...C/C++...CodeGeneration...Multithreaded library. */

#include "Everything.h"

typedef struct {	/* grep thread's data structure. */
	int argc;
	TCHAR targv [4] [MAX_COMMAND_LINE];
} GREP_THREAD_ARG;

typedef GREP_THREAD_ARG *PGR_ARGS;
static DWORD WINAPI ThGrep (PGR_ARGS pArgs);

VOID _tmain (int argc, LPTSTR argv [])

/* Create a separate THREAD to search each file on the command line.
	Report the results as they come in.
	Each thread is given a temporary file, in the current
	directory, to receive the results.
	This program modifies Program 8-1, which used processes. */
{
	PGR_ARGS gArg;		/* Points to array of thread args. */ 
	HANDLE * tHandle;	/* Points to array of thread handles. */
	TCHAR CmdLine [MAX_COMMAND_LINE];
	BOOL ok;
	DWORD ThdIdxP, ThId;
	int iThrd, ThdCnt;
	STARTUPINFO StartUp;
	PROCESS_INFORMATION ProcessInfo;

	/* Start up info for each new process. */

	GetStartupInfo (&StartUp);

	if (argc < 3)
		ReportError (_T ("No file names."), 1, TRUE);
	
	/* Create a separate "grep" thread for each file on the command line.
		Each thread also gets a temporary file name for the results.
		argv [1] is the search pattern. */

	tHandle = malloc ((argc - 2) * sizeof (HANDLE));
	gArg = malloc ((argc - 2) * sizeof (GREP_THREAD_ARG));

	for (iThrd = 0; iThrd < argc - 2; iThrd++) {

			/* Set:	targv [1] to the pattern
				targv [2] to the input file
				targv [3] to the output file. */

		_tcscpy (gArg [iThrd].targv [1], argv [1]); /* Pattern. */
		_tcscpy (gArg [iThrd].targv [2], argv [iThrd + 2]); /* Search file. */

		if (GetTempFileName	/* Temp file name */
				(".", "Gre", 0,	gArg [iThrd].targv [3]) == 0)
			ReportError (_T ("Temp file failure."), 3, TRUE);

		/* Output file. */

		gArg [iThrd].argc = 4;

		/* Create a thread to execute the command line. */

		tHandle [iThrd] = CreateThread (
				NULL, 0, ThGrep, &gArg[iThrd], 0, ThId);

		if (tHandle [iThrd] == 0)
			ReportError (_T ("ThreadCreate failed."), 4, TRUE);
	}

	/* Threads are all running. Wait for them to complete
	 	one at a time and put out the results. */
	/*  Redirect output for "cat" process listing results. */

	StartUp.dwFlags = STARTF_USESTDHANDLES;
	StartUp.hStdOutput = GetStdHandle (STD_OUTPUT_HANDLE);
	StartUp.hStdError = GetStdHandle (STD_ERROR_HANDLE);

	ThdCnt = argc - 2;
	while (ThdCnt > 0) {
		ThdIdxP = WaitForMultipleObjects (ThdCnt, tHandle, TRUE, INFINITE);
		iThrd = (int) ThdIdxP - (int) WAIT_OBJECT_0;
		if (iThrd < 0 || iThrd >= ThdCnt)
			ReportError (_T ("Thread wait error."), 5,TRUE);
		CloseHandle (tHandle [iThrd]);
		
		/* List file contents (if a pattern match was found)
			and wait for the next thread to terminate. */

		if (GetCompressedFileSize (gArg [iThrd].targv [3], NULL) > 2) {
			if (argc > 3) {		/* Print  file name if more than one. */
				_tprintf (_T ("**Search results - file: %s\n"),
						gArg [iThrd].targv [2]);
				fflush (stdout);
			}
			_stprintf (CmdLine, _T ("%s%s"), _T ("cat "), 
						gArg [iThrd].targv [3]);

			ok = CreateProcess (NULL, CmdLine, NULL, NULL,
					TRUE, 0, NULL, NULL, &StartUp, &ProcessInfo);

			if (!ok) ReportError (_T ("Failure executing cat."), 6, TRUE);
			WaitForSingleObject (ProcessInfo.hProcess, INFINITE);
			CloseHandle (ProcessInfo.hProcess);
			CloseHandle (ProcessInfo.hThread);
		}

		if (!DeleteFile (gArg [iThrd].targv [3]))
			ReportError (_T ("Cannot delete temp file."), 7, TRUE);

		/* Move the handle of the last thread in the list
			to the slot occupied by thread that just completed
			and decrement the thread count. Do the same for
			the temp file names. */

		tHandle [iThrd] = tHandle [ThdCnt - 1];
		_tcscpy (gArg [iThrd].targv [3], gArg [ThdCnt - 1].targv [3]);
		_tcscpy (gArg [iThrd].targv [2], gArg [ThdCnt - 1].targv [2]);
		ThdCnt--;
	}
	free (tHandle);
	free (gArg);
}

/* Source code for grep follows and is omitted from text. */
/* The form of the code is:
	static DWORD WINAPI ThGrep (GR_ARGS pArgs)
	{
	}
*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/*	grep, written as a function to be executed on a thread. */
/*	Copyright 1995, Alan R. Feuer. */
/*	Modified version: The input and output file names
	are taken from the argument data structure for the file.
	This function uses the C library and therefore must
	be invoked by _beginthreadex. */

/*	grep pattern file(s)
	Looks for pattern in files. A file is scanned line-by-line.

	These metacharacters are used:
		*	matches zero or more characters
		?	matches exactly one character
		[...]	specifies a character class
			matches any character in the class
		^	matches the beginning of the line
		$	matches the end of the line
	In addition, the standard C escape sequences are
	understood: \a, \b, \f, \t, \v */

/*	Codes for pattern metacharacters. */

#define ASTRSK		1
#define QM		2
#define BEGCLASS	3
#define ENDCLASS	4
#define ANCHOR		5

FILE * openFile (char *, char *);
void prepSearchString (char *, char *);

BOOL patternMatch (char *,char *);

/* Other codes and definitions. */

#define EOS '\0'

/* Options for pattern match. */
static int patternSeen = FALSE;
static BOOL ignoreCase = FALSE;

static DWORD WINAPI ThGrep (PGR_ARGS pArgs)
{
	/* Modified version - the first argument is the
		pattern, the second is the input file and the
		third is the output file.
		argc is not used but is assumed to be 4. */

	char *file;
	int i, showName = FALSE, argc;
	char pattern [256];
	char string [2048];
	TCHAR argv [4] [MAX_COMMAND_LINE];
	FILE *fp, *fpout;

	argc = pArgs->argc;
	_tcscpy (argv [1], pArgs->targv [1]);
	_tcscpy (argv [2], pArgs->targv [2]);
	_tcscpy (argv [3], pArgs->targv [3]);
	if (argc < 3 ) {
		puts ("Usage: grep output_file pattern file(s)");
		exit(0);
	}

	/* Open the output file. */

	fpout = openFile (file = argv [argc - 1],"wb");
	if (fpout == NULL) {
		printf ("Failure to open output file.");
		exit (1);
	}

	for (i = 1; i < argc - 1; ++i ) {
		if (argv [i] [0] == '-' ) {
			switch (argv [i] [1] ) {
				case 'y':
					ignoreCase = TRUE;
					break;
				}
		} else {
			if (!patternSeen++)
				prepSearchString (argv [i], pattern);
			else if ((fp = openFile (file = argv [i], "rb"))
					!= NULL ) {
				if (!showName && i < argc - 2 ) ++showName;
				while (fgets (string, sizeof (string), fp)
						!= NULL && !feof (fp)) {
					if (ignoreCase) _strlwr (string);
					if (patternMatch (pattern, string))
						if (showName) {
							fputs (file,fpout);
							fputs (string, fpout);
					} else fputs (string, fpout);
				}
				fclose (fp);
				fclose (fpout);
			}
		}
	}
	return 0;
}

static FILE *
openFile (char * file, char * mode)
{
	FILE *fp;

	/* printf ("Opening File: %s", file); */

	if ((fp = fopen (file, mode)) == NULL )
		perror (file);
	return (fp);
}

static void
prepSearchString (char *p, char *buf)

/* Copy prep'ed search string to buf. */
{
	register int c;
	register int i = 0;

	if (*p == '^' ) {
		buf [i++] = ANCHOR;
		++p;
	}

	for(;;) {
		switch (c = *p++) {
		case EOS: goto Exit;
		case '*': if (i >= 0 && buf [i - 1] != ASTRSK)
				c = ASTRSK; break;
		case '?': c = QM; break;
		case '[': c = BEGCLASS; break;
		case ']': c = ENDCLASS; break;

		case '\\':
			switch (c = *p++) {
			case EOS: goto Exit;
			case 'a': c = '\a'; break;
			case 'b': c = '\b'; break;
			case 'f': c = '\f'; break;
			case 't': c = '\t'; break;
			case 'v': c = '\v'; break;
			case '\\': c = '\\'; break;
			}
			break;
		}

		buf [i++] = (ignoreCase ? tolower (c) : c);
	}

Exit:
	buf [i] = EOS;
}

static BOOL
patternMatch (char *pattern, char *string)

	/* Return TRUE if pattern matches string. */
{
	register char pc, sc;
	char *pat;
	BOOL anchored;

	if (anchored = (*pattern == ANCHOR))
		++pattern;

Top:			/* Once per char in string. */
	pat = pattern;

Again:
	pc = *pat;
	sc = *string;

	if (sc == '\n' || sc == EOS ) {
				/* at end of line or end of text */
		if (pc == EOS ) goto Success;
		else if (pc == ASTRSK ) {
				/* patternMatch (pat + 1,base, index, end) */
			++pat;
			goto Again;
		} else return (FALSE);
	} else {
		if (pc == sc || pc == QM ) {
					/* patternMatch (pat + 1,string + 1) */
			++pat;
			++string;
			goto Again;
		} else if (pc == EOS) goto Success;
		else if (pc == ASTRSK ) {
			if (patternMatch (pat + 1,string)) goto Success;
			else {
					/* patternMatch (pat, string + 1) */
				++string;
				goto Again;
			}
		} else if (pc == BEGCLASS ) { /* char class */
			BOOL clmatch = FALSE;
			while (*++pat != ENDCLASS ) {
				if (!clmatch && *pat == sc ) clmatch = TRUE;
			}
			if (clmatch) {
				++pat;
				++string;
				goto Again;
			}
		}
	}

	if (anchored) return (FALSE);

	++string;
	goto Top;

Success:
	return (TRUE);
}

	

