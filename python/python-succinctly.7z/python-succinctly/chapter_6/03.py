#!/usr/bin/env python3

contacts = {'David': '555-0123', 'Tom': '555-5678'}
contacts['Nora'] = '555-2413'
print(contacts)
print(len(contacts))
