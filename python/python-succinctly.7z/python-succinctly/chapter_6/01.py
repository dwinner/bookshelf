#!/usr/bin/env python3

contacts = {'David': '555-0123', 'Tom': '555-5678'}
davids_phone = contacts['David']
toms_phone = contacts['Tom']

print('Dial {} to call David.'.format(davids_phone))
print('Dial {} to call Tom.'.format(toms_phone))
