#!/usr/bin/env python3

contacts = {
    'David': ['555-0123', '555-0000'],
    'Tom': '555-5678'
}

for number in contacts['David']:
    print('Phone: {}'.format(number))
