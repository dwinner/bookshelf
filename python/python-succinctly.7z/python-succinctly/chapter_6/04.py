#!/usr/bin/env python3

contacts = {'David': '555-0123', 'Tom': '555-5678'}
del contacts['David']
print(contacts)
