#!/usr/bin/env python3

contacts = {
    'David': ['555-0123', '555-0000'],
    'Tom': '555-5678'
}

print ('555-5678' in contacts.values())
