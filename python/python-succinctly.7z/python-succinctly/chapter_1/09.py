#!/usr/bin/env python3
a = 'asparagus'[0]
r = 'asparagus'[4]
