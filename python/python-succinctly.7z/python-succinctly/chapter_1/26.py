#!/usr/bin/env python3
first = 'Python'
second = 'is'
third = 'fun'
print('{} {} {}.'.format(first, second, third))
