#!/usr/bin/env python3
last3letters = 'XYZ'
last_three_letters = 'XYZ'
lastThreeLetters = 'XYZ'
