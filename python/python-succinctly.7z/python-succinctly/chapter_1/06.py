#!/usr/bin/env python3
sentence = 'He said, "That asparagus tastes great!"'
