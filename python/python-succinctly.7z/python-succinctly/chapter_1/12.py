#!/usr/bin/env python3
vegetable = 'asparagus'
vegetable_len = len(vegetable)
print(vegetable_len)
