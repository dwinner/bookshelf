#!/usr/bin/env python3
animal = 'deer'
vegetable = 'spinach'
mineral = 'aluminum'

print('Here is an animal, a vegetable, and a mineral.')
print(animal)
print(vegetable)
print(mineral)
