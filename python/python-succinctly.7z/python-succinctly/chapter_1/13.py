#!/usr/bin/env python3
vegetable = 'asparagus'
print(len(vegetable))
