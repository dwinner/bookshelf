#!/usr/bin/env python3
print('Python {} fun.'.format('is'))
print('{} {} {}'.format('Python', 'is', 'fun.'))
