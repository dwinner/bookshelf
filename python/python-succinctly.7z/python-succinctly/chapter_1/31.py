#!/usr/bin/env python3
vegetable = input('Enter a name of a vegetable: ')
print('{} is a lovely vegetable.'.format(vegetable))
