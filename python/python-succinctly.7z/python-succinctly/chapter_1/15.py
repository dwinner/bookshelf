#!/usr/bin/env python3
vegetable = 'Asparagus'
print(vegetable.lower())
