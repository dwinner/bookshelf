#!/usr/bin/env python3
print('Python {0} {1} and {1} {0} awesome!'.format('is', 'fun'))
