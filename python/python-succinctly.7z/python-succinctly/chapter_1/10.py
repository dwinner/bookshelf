#!/usr/bin/env python3
vegetable = 'asparagus'
first_char = vegetable[0]
