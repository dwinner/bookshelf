#!/usr/bin/env python3
good_times = 'fun ' * 3
print(good_times)
