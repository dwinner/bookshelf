#!/usr/bin/env python3
vegetable = 'asparagus'
print(vegetable)
print('onion')
