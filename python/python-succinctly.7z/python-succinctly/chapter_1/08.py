#!/usr/bin/env python3
sentence_in_double = "She said, \"That's some great tasting asparagus!\""
sentence_in_single = 'She said, "That\'s some great tasting asparagus!"'
