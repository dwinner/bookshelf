#!/usr/bin/env python3
sentence = "That's some great tasting asparagus!"
