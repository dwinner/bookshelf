#!/usr/bin/env python3
print('Python' + 'is' + 'fun.')
