#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal', 'fox', 'owl', 'whale', 'elk']

index = 0

while index < len(animals):
    print(animals[index])
    index += 1
