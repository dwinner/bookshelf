#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal']
print(len(animals))
animals.append('fox')
print(len(animals))
