#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal']
more_animals = ['fox', 'owl', 'whale']
all_animals = animals + more_animals
print(all_animals)
