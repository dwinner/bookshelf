#!/usr/bin/env python3

for number in range(0, 10, 2):
    print(number)
