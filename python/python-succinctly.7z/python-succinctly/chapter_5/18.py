#!/usr/bin/env python3

for number in range(2, 4):
    print(number)
