#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal']
animals.append('fox')
print(animals[-1])
