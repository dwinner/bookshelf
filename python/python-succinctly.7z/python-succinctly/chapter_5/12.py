#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal']
for animal in animals:
    print(animal.upper())
