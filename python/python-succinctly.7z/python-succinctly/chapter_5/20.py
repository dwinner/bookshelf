#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal', 'fox', 'owl', 'whale', 'elk']
for number in range(0, len(animals), 2):
    print(animals[number])
