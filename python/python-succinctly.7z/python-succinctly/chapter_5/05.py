#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal']
animals.extend(['fox', 'owl'])
print(animals)

more_animals = ['whale', 'elk']
animals.extend(more_animals)
print(animals)
