#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal']
sheep_index = animals.index('sheep')
print(sheep_index)
