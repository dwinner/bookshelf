#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal']
lion_index = animals.index('lion')
print(lion_index)
