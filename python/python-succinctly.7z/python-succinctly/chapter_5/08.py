#!/usr/bin/env python3

part_of_a_whale = 'whale'[1:3]
print(part_of_a_whale)
