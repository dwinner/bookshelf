#!/usr/bin/env python3

animals = ['toad', 'lion', 'seal']
animals.insert(0, 'whale')
print(animals)

animals.insert(2, 'owl')
print(animals)
