#!/usr/bin/env python3

for number in range(4):
    print(number)
