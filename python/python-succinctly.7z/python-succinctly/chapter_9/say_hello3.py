#!/usr/bin/env python3


def say_hello():
    print('Hello!')


def main():
    print('Hello from say_hello3.py!')
    say_hello()

if __name__ == '__main__':
    main()
