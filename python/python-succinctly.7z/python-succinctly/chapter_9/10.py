#!/usr/bin/env python3

import say_hello3
say_hello3.say_hello()
