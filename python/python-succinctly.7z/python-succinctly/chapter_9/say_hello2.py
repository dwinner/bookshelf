#!/usr/bin/env python3


def say_hello():
    print('Hello!')

print('Hello from say_hello2.py!')
