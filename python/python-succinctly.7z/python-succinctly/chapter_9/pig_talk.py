#!/usr/bin/env python3

import pig_say


def main():
    pig_say.pig_say('Feed me.')
    pig_say.pig_say('Oink.  Oink.')

if __name__ == '__main__':
    main()
