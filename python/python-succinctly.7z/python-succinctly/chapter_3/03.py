#!/usr/bin/env python3

if 43 < 44:
    print('Forty-three is less than forty-four.')
