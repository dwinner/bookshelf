#!/usr/bin/env python3

the_true_boolean = True
the_other_boolean = False
print(the_true_boolean)
print(the_other_boolean)
