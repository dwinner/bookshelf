#!/usr/bin/env python3

is_two_equal_to_three = 2 == 3
print(is_two_equal_to_three)
