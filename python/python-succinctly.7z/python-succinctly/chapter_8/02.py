#!/usr/bin/env python3

hosts = open('C:/Windows/System32/drivers/etc/hosts')
hosts_file_contents = hosts.read()
print(hosts_file_contents)
