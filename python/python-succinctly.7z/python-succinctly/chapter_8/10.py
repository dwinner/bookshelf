#!/usr/bin/env python3

with open('file.txt') as the_file:
    print(the_file.mode)
