#!/usr/bin/env python3


def say_hello(first, last='Carberry'):
    """Say hello."""
    print('Hello {} {}!'.format(first, last))

help(say_hello)
