#!/usr/bin/env python3


def say_hello():
    print('Hello!')

say_hello()
