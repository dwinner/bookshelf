#!/usr/bin/env python3


def say_hello(first, last):
    print('Hello {} {}!'.format(first, last))

say_hello(first = 'Josiah', last = 'Carberry')
say_hello(last = 'Carberry', first = 'Hank')
