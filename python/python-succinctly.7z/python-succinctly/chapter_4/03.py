#!/usr/bin/env python3

say_hello()


def say_hello():
    print('Hello!')
