#!/usr/bin/env python3


def say_hello(name):
    print('Hello {}!'.format(name))

say_hello()
