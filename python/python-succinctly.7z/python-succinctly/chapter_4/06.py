#!/usr/bin/env python3


def say_hello(name = 'there'):
    print('Hello {}!'.format(name))

say_hello()
say_hello('Erin')
