#!/usr/bin/env python3


def say_hello(first, last='Carberry'):
    print('Hello {} {}!'.format(first, last))

say_hello('Josiah')
say_hello('Hank', 'Mobley')
