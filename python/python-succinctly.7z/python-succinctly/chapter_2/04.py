#!/usr/bin/env python3

quantity = 4
quantity_string = '4'
