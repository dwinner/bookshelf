#!/usr/bin/env python3

integer = 23
float = 2.3
