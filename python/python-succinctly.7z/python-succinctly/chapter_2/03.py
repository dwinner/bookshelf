#!/usr/bin/env python3

sum = 3 + 4
difference = 200 - 2
new_number = sum + difference
print(new_number)
print(sum / sum)
print(sum + 1)
