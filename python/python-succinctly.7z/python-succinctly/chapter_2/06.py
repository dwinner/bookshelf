#!/usr/bin/env python3

quantity_string = '4'
total = int(quantity_string) + 1
print(total)
