#!/usr/bin/env python3

sum = 3 + 2
difference = 88 - 2
product = 4 * 2
quotient = 16 / 4
power = 3 ** 5
remainder = 7 % 3

print('Sum: {}'.format(sum))
print('Difference: {}'.format(difference))
print('Product: {}'.format(product))
print('Quotient: {}'.format(quotient))
print('Power: {}'.format(power))
print('Remainder: {}'.format(remainder))
