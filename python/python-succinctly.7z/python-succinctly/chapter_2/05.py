#!/usr/bin/env python3

quantity_string = '4'
total = quantity_string + 1
