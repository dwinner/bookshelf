#!/usr/bin/env python3

# The following code:
#     Computes the hosting costs for one server.
#     Determines the duration of hosting that can be purchased given a budget.
