#!/usr/bin/env python3

contact_info = ['555-0123', 'david@gmail.com']
(phone, email) = contact_info
print(phone)
print(email)
