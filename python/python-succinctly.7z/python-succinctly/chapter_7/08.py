#!/usr/bin/env python3

contacts = [('David', '555-0123'), ('Tom', '555-5678')]
for (name, phone) in contacts:
    print("{}'s phone number is {}.".format(name, phone))
