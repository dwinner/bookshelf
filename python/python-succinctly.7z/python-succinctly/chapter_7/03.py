#!/usr/bin/env python3

months_of_the_year_tuple = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
months_of_the_year_list = list(months_of_the_year_tuple)
print('months_of_the_year_tuple is {}.'.format(type(months_of_the_year_tuple)))
print('months_of_the_year_list is {}.'.format(type(months_of_the_year_list)))

animals_list = ['toad', 'lion', 'seal']
animals_tuple = tuple(animals_list)
print('animals_list is {}.'.format(type(animals_list)))
print('animals_tuple is {}.'.format(type(animals_tuple)))
