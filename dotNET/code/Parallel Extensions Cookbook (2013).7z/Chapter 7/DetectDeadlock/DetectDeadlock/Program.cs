﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace DetectDeadlock
{
    class Program
    {
        static void Main()
        {
            int taskCount = 5;
            var countdownEvent = new CountdownEvent(taskCount);
            var tasks = new Task[taskCount];
            
            for(int i = 0; i < taskCount; i++)
            {
               tasks[i] = Task.Factory.StartNew((state) =>
                   {
                       countdownEvent.Signal();
                       tasks[(((int)state)+1)%taskCount].Wait();
                   },i);
            }

            var task1 = new Task(() =>
            {
                Thread.Sleep(500);                
            });

            var task2 = new Task(() =>
            {
                Thread.Sleep(500);
            });

            task1.Start();
            task2.Start();

           countdownEvent.Wait();
           Debugger.Break();    
        }
    }
}
