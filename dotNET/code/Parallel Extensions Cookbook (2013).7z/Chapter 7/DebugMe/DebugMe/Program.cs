﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace DebugMe
{
    class Program
    {
        static void Main()
        {
            var task1 = Task.Factory.StartNew(() => Method1());
            var task2 = Task.Factory.StartNew(() => Method3());
            Console.ReadLine();
        }

        static void Method1()
        {
            Console.WriteLine("In Method1.");
            for (int i = 0; i < 3; i++)
            {
                Task.Factory.StartNew(index => Method2((int)index), i);               
            }
        }

        static void Method2(int number)
        {
            Random rnd = new Random();
            var sum = number + rnd.Next(1,10);
            Console.WriteLine("In Method2. Value:{0}", sum);
            Method4(sum);            
        }

        static void Method3()
        {
            Console.WriteLine("In Method3.");
            for (int i = 0; i < 3; i++)
            {
                Task.Factory.StartNew(() =>
                {
                    Task.Factory.StartNew(index => Method2((int)index), i);                     
                });

                Thread.Sleep(10);
            }
            
        }

        static void Method4(int number)
        {
            Console.WriteLine("In Method4.", number);
            Debugger.Break();
        }


    }
}

