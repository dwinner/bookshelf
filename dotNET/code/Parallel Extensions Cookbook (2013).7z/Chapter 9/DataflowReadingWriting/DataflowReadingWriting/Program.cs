﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace DataflowReadingWriting
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a BufferBlock object. 
            var bufferingBlock = new BufferBlock<int>();

            // Post some messages to the block. 
            for (int i = 0; i < 10; i++)
            {
                bufferingBlock.Post(i*i);
            }

            // Receive the messages back . 
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(bufferingBlock.Receive());
            }

            Console.WriteLine("Finished. Press any key to exit.");
            Console.ReadLine();

        }

    }
}
