﻿using System;
using System.Linq;
using System.Threading.Tasks.Dataflow;
using System.Net;
using System.Threading;

namespace CancelDataflow
{
    class Program
    {
        static void Main(string[] args)
        {

            // Create a cancellation token source
            CancellationTokenSource cancellationSource = new CancellationTokenSource();            
            
            // Download a book as a string
            var downloadBook = new TransformBlock<string, string>(uri =>
            {
                Console.WriteLine("Downloading the book...");

                return new WebClient().DownloadString(uri);
            },
            new ExecutionDataflowBlockOptions
            {
                CancellationToken = cancellationSource.Token
            });



            // splits text into an array of strings. 
            var createWordList = new TransformBlock<string, string[]>(text =>
            {
                Console.WriteLine("Creating list of words...");

                // Remove punctuation  
                char[] tokens = text.ToArray();
                for (int i = 0; i < tokens.Length; i++)
                {
                    if (!char.IsLetter(tokens[i]))
                        tokens[i] = ' ';
                }
                text = new string(tokens);

                return text.Split(new char[] { ' ' },
                   StringSplitOptions.RemoveEmptyEntries);
            },
            new ExecutionDataflowBlockOptions
            {
                CancellationToken = cancellationSource.Token
            });

            // Remove short words and return the count 
            var filterWordList = new TransformBlock<string[], int>(words =>
            {
                Console.WriteLine("Counting words...");

                var wordList = words.Where(word => word.Length > 3).OrderBy(word => word)
                   .Distinct().ToArray();
                return wordList.Count();
            },
            new ExecutionDataflowBlockOptions
            {
                CancellationToken = cancellationSource.Token
            });

            var printWordCount = new ActionBlock<int>(wordcount =>
            {
                Console.WriteLine("Found {0} words",
                   wordcount);
            },
            new ExecutionDataflowBlockOptions
            {
                CancellationToken = cancellationSource.Token
            });

            downloadBook.LinkTo(createWordList);
            createWordList.LinkTo(filterWordList);
            filterWordList.LinkTo(printWordCount);

            // create a continuation task that marks the next block in the pipeline as completed. 
            
            downloadBook.Completion.ContinueWith(t =>
            {
                if (t.IsFaulted) ((IDataflowBlock)createWordList).Fault(t.Exception);
                else createWordList.Complete();
            });
            createWordList.Completion.ContinueWith(t =>
            {
                if (t.IsFaulted) ((IDataflowBlock)filterWordList).Fault(t.Exception);
                else filterWordList.Complete();
            });
            filterWordList.Completion.ContinueWith(t =>
            {
                if (t.IsFaulted) ((IDataflowBlock)printWordCount).Fault(t.Exception);
                else printWordCount.Complete();
            });            
            
            try
            {
                Console.WriteLine("Starting...");                
                
                // Download Origin of Species
                downloadBook.Post("http://www.gutenberg.org/files/2009/2009.txt");

                // Mark the head of the pipeline as complete. 
                downloadBook.Complete();

                // Cancel the operation
                cancellationSource.Cancel();

                printWordCount.Completion.Wait();

            }
            catch (AggregateException ae)
            {
                foreach (Exception ex in ae.InnerExceptions)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            finally
            {
                Console.WriteLine("Finished. Press any key to exit.");
                Console.ReadLine();
            }

            
            

        }
    }
}
