﻿using System;
using System.Threading;
using System.Threading.Tasks.Dataflow;

namespace JoinBlock
{
    class Program
    {
        abstract class Resource
        {
        }

        class MemoryResource : Resource
        {
        }

        class NetworkResource : Resource
        {
        }

        

        
        static void Main(string[] args)
        {
            var networkResources = new BufferBlock<NetworkResource>();
            var memoryResources = new BufferBlock<MemoryResource>();

           var joinResources =
               new JoinBlock<NetworkResource, MemoryResource>(
                  new GroupingDataflowBlockOptions
                  {
                      Greedy = false
                  });

            var networkMemoryAction =
               new ActionBlock<Tuple<NetworkResource, MemoryResource>>(
                  data =>
                  {
                      Console.WriteLine("Network worker: using resources.");
                      Thread.Sleep(new Random().Next(500, 2000));
                      Console.WriteLine("Network worker: finished using resources.");
                      networkResources.Post(data.Item1);
                      memoryResources.Post(data.Item2);
                  });

            networkResources.LinkTo(joinResources.Target1);
            memoryResources.LinkTo(joinResources.Target2);

            joinResources.LinkTo(networkMemoryAction);
           
            networkResources.Post(new NetworkResource());
            networkResources.Post(new NetworkResource());
            networkResources.Post(new NetworkResource());

            memoryResources.Post(new MemoryResource());

            Thread.Sleep(10000);
            Console.ReadLine();

        }
    }
}
