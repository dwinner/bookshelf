﻿using System;
using System.Threading;
using System.Threading.Tasks.Dataflow;

namespace UnlinkBlocks
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                var tokenSource = new CancellationTokenSource();

                Func<int, int> action = n => DoCalculation(n, tokenSource);
                var calculation1 = new TransformBlock<int, int>(action);
                var calculation2 = new TransformBlock<int, int>(action);
                var calculation3 = new TransformBlock<int, int>(action);

                calculation1.Post(11);
                calculation2.Post(21);
                calculation3.Post(31);

                int result = ReceiveFromAny(calculation1, calculation2, calculation3);

                // Cancel all calls to TrySolution that are still active.
                tokenSource.Cancel();

                // Print the result to the console.
                Console.WriteLine("The solution is {0}.", result);
            }
            catch (AggregateException) { }
            finally { Console.ReadLine(); }

        }

        public static T ReceiveFromAny<T>(params ISourceBlock<T>[] sources)
        {
            var writeOnceBlock = new WriteOnceBlock<T>(e => e);
            foreach (var source in sources)
            {
                source.LinkTo(writeOnceBlock, new DataflowLinkOptions { MaxMessages = 1 });
            }            
            return writeOnceBlock.Receive();
        }

        static int DoCalculation(int n, CancellationTokenSource tokenSource)
        {
            // simulate a workload and return result
            SpinWait.SpinUntil(() => tokenSource.IsCancellationRequested,
                new Random().Next(2000));
            return n + 5;
        }

    }
}
