﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LockExample
{
    public class Account
    {
        private double _balance;
        private object _locker = new object();

        public Account(double initialBalance)
        {
            _balance = initialBalance;
        }
        
        public double Withdraw(double amount)
        {

            if (_balance < 0)
            {
                throw new Exception("Account has a negative balance.");
            }

            lock (_locker)
            {
                if (_balance >= amount)
                {
                    Console.WriteLine("Starting balance :  " + _balance);
                    Console.WriteLine("Withdraw  amount : -" + amount);
                    _balance = _balance - amount;
                    Console.WriteLine("Current balance :  " + _balance);
                    return amount;
                }
                else
                {
                    return 0;
                }
            }
        }

    }
}
