﻿using System;
using System.Threading.Tasks;

namespace LockExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Account account = new Account(1000);
            Task task1 = Task.Factory.StartNew(() => DoTransactions(account));
            Task task2 = Task.Factory.StartNew(() => DoTransactions(account));
            Console.ReadLine();

        }

        static void DoTransactions(Account account)
        {
            Random r = new Random();
            for (int i = 0; i < 10; i++)
            {
                account.Withdraw((double)r.Next(1, 100));
            }
        }
    }
}
