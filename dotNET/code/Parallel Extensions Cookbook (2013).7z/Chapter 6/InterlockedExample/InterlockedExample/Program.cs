﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace InterlockedExample
{
    class Program
    {
        static void Main(string[] args)
        {
            var account = new Account();            
            var taskList = new List<Task>();

            for (int i = 0; i < 5; i++)
            {
                taskList.Add(Task.Factory.StartNew(() =>
                {
                    for (int x = 0; x < 50; x++)
                    {
                        Thread.Sleep(50);
                        Interlocked.Add(ref account.Balance, 10);
                        Console.WriteLine("Task {0} added 10 to the balance.", Thread.CurrentThread.ManagedThreadId);                       
                    }
                }));
            }
            Task.WaitAll(taskList.ToArray());
            Console.WriteLine("Expected account balance: 2500,  Actual account balance: {0}", account.Balance);
            Console.ReadLine();
        }
    }

    class Account
    {
        public int Balance = 0;
    }
}