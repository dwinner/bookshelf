﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpinAndWait
{
    class Program
    {
        private static ManualResetEventSlim resetEvent; 
        
        static void Main(string[] args)
        {
            resetEvent = new ManualResetEventSlim(false); 
            StartTasks();

            Thread.Sleep(1000);
            Console.WriteLine("Main thread setting event");
            resetEvent.Set();
            Thread.Sleep(500);
            Console.WriteLine("Main thread re-setting event");
            resetEvent.Reset();
            Thread.Sleep(1000);
            Console.WriteLine("Main thread setting event again");
            resetEvent.Set();

            Console.WriteLine("Finished. Press <Enter> to exit.");
            Console.ReadLine(); 
        }

         private static void StartTasks()   
         {   
            for (int i = 0; i < 5; i++)   
            {
                Task.Factory.StartNew(()=>
                {   
                    Thread.Sleep(2000);   
                    Console.WriteLine("Task {0} waiting for event...", Thread.CurrentThread.ManagedThreadId);   
                    resetEvent.Wait();   
                    Console.WriteLine("Task {0} event signalled", Thread.CurrentThread.ManagedThreadId);   
                } );   
            }               
        }

    }
}
