﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MonitorExample
{
    class Program
    {
        static void Main(string[] args)
        {
            
            var writer = new ConsoleWriter();
            var taskList = new List<Task>();
            for (int i = 0; i < 3; i++)
            {
                taskList.Add(Task.Factory.StartNew(()=>
                    {
                        writer.WriteNumbers();
                    }));                
            }
            
            Task.WaitAll(taskList.ToArray());
            Console.WriteLine("Finished. Press <Enter> to exit.");
            Console.ReadLine();
        }       
    }
}
