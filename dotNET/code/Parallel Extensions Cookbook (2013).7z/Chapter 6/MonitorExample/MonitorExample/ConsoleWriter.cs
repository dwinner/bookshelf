﻿using System;
using System.Threading;

namespace MonitorExample
{
    public class ConsoleWriter
    {
        private object _locker = new object();

        public void WriteNumbers()
        {
            Monitor.Enter(_locker);
            try
            {
                for (int number = 0; number <= 5; number++)
                {
                    Thread.Sleep(100);
                    Console.Write(number + ",");
                }
                Console.WriteLine();
            }
            finally
            {
                Monitor.Exit(_locker);
            }
        }

        public void WriteNumbersUnprotected()
        {
            for (int numbers = 0; numbers < 5; numbers++)
            {
                Thread.Sleep(100);
                Console.Write(numbers + ",");
            }
            Console.WriteLine();
        }

    }
}
