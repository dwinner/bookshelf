﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace SemaphoreSlimExample
{
    class Program
    {
        static SemaphoreSlim _semaphoreSlim = new SemaphoreSlim(3);
        
        static void Main(string[] args)
        {
            for (int i = 1; i <= 5; i++)
            {
                Task.Factory.StartNew((num) =>
                    {
                        Enter(num);
                    }, i);
            }
            Console.ReadLine();
        }

        static void Enter(object id)
        {
            Console.WriteLine("Task {0} is trying to enter.",id);
            _semaphoreSlim.Wait();
            Console.WriteLine("Task {0} has entered.", id);   
            Thread.Sleep(2000); //Shared resource           
            Console.WriteLine("Task {0} is leaving.", id); 
            _semaphoreSlim.Release();
        }

    }
}
