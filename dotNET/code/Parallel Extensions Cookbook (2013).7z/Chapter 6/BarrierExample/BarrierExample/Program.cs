﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace BarrierExample
{
    class Program
    {
        public static void Main()
        {
            Barrier barrier = new Barrier(4, (b) => Console.WriteLine("Barrier phase {0} reached.", b.CurrentPhaseNumber));
            var task1 = Task.Factory.StartNew(() => OperationWithBarrier(barrier));
            var task2 = Task.Factory.StartNew(() => OperationWithBarrier(barrier));
            var task3 = Task.Factory.StartNew(() => OperationWithBarrier(barrier));
            var task4 = Task.Factory.StartNew(() => OperationWithBarrier(barrier));
            Task.WaitAll(task1, task2, task3, task4);
            Console.ReadLine();
        }

        static void OperationWithBarrier(Barrier barrier)
        {
            for (int i = 0; i < 3; ++i)
            {
                var threadId = Thread.CurrentThread.ManagedThreadId;
                Console.WriteLine("Thread {0} has reached wait.", threadId);
                barrier.SignalAndWait(100);
                Console.WriteLine("Thread {0} after wait wait.", threadId);
            }
        } 
    }
}
