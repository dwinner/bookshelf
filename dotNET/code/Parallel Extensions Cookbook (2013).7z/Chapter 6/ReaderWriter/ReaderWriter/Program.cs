﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ReaderWriter
{
    class Program
    {
        const int MaxNumberValues = 5;
        static int[] _array = new int[MaxNumberValues];
        static ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();

        static void Main(string[] args)
        {
            var taskList = new List<Task>();
            taskList.Add(Task.Factory.StartNew(() => Write()));
            Thread.Sleep(1000);
            for (int i = 0; i < 3; i++)
            {
                taskList.Add(Task.Factory.StartNew(()=>Read()));
            }
            Task.WaitAll(taskList.ToArray());
            Console.WriteLine("Finished. Press <Enter> to exit.");
            Console.ReadKey();
        }

        static void Write()
        {
            int id = Thread.CurrentThread.ManagedThreadId;
            for (int i = 0; i < MaxNumberValues; ++i)
            {
                _lock.EnterWriteLock();
                Console.WriteLine("Entered WriteLock on thread {0}", id);
                _array[i] = i*i;
                Console.WriteLine("Added {0} to array on thread {1}", _array[i], id);

                Console.WriteLine("Exiting WriteLock on the thread {0}", id);
                _lock.ExitWriteLock();
                Thread.Sleep(1000);
            }
        }

        static void Read()
        {
            int idNumber = Thread.CurrentThread.ManagedThreadId;
            for (int i = 0; i < MaxNumberValues; ++i)
            {
                _lock.EnterReadLock();
                Console.WriteLine("Entered ReadLock on the thread {0}", idNumber);
                StringBuilder sbObj = new StringBuilder();
                for (int j = 0; j < i; j++)
                {
                    if (sbObj.Length > 0) sbObj.Append(", ");
                    sbObj.Append(_array[j]);
                }
                Console.WriteLine("Array: {0} on the thread {1}", sbObj, idNumber);
                Console.WriteLine("Exiting the ReadLock on thread {0}", idNumber);
                _lock.ExitReadLock();
                Thread.Sleep(2000);
            }
        }
    }
}
