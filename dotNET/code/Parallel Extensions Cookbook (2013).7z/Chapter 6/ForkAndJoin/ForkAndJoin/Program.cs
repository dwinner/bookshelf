﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace ForkAndJoin
{
    class Program
    {
        private static CountdownEvent _countdownEvent;
        private const int BEGIN_TASKS = 2;
        private const int END_TASKS = 6;

        static void Main(string[] args)
        {
            _countdownEvent = new CountdownEvent(BEGIN_TASKS);
            var task1 = Task.Factory.StartNew(() =>
                {
                    for (int i = BEGIN_TASKS; i <= END_TASKS; i++)
                    {
                        Console.WriteLine("**** Start simulating {0} tasks.", i);
                        _countdownEvent.Reset(i);
                        SimulateTasks(i);
                        _countdownEvent.Wait();
                        Console.WriteLine("**** End simulating {0} tasks.", i);
                    }
                });
            try
            {
                task1.Wait();
                Console.WriteLine("Finished. Press <Enter> to exit.");
            }
            finally
            {
                _countdownEvent.Dispose();
            }
            Console.ReadLine();
        }

        private static void SimulateTasks(int taskCount)
        {
            for (int i = 0; i < taskCount; i++)
            {
                Task.Factory.StartNew((num) =>
                    {
                        try
                        {
                            var taskNumber = (int)num;
                            Thread.Sleep(2500);
                            Console.WriteLine("Task {0} simultated.", taskNumber);
                        }
                        finally
                        {
                            _countdownEvent.Signal();
                        }
                    },i);
            }
        }
    }
}
