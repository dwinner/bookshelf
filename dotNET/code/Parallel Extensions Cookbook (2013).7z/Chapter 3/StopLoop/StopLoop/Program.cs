﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace StopLoop
{
    class Program
    {
        static void Main()
        {
            char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/','"','(',')', '\u000A' };
            var client = new WebClient();
            const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
            client.Headers.Add("user-agent", headerText);
            var words = client.DownloadString(@"http://www.gutenberg.org/files/2009/2009.txt");
            var wordList = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries).Where(word => word.Length > 5).ToList();
            wordList.Sort();
            var loopResult = Parallel.ForEach(wordList, (currentWord, loopState) =>
            {
                if (!currentWord.Equals("immutability"))
                    Console.WriteLine(currentWord);
                else
                {
                    loopState.Stop();
                    Console.WriteLine(currentWord);
                    Console.WriteLine("Loop stopped: {0}", loopState.IsStopped);
                }
            });
            Console.WriteLine("Loop Completed : {0}", loopResult.IsCompleted);
            Console.ReadLine();
        }
    }
}
