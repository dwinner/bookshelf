﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace DegreeOfParallelism
{
    class Program
    {

        static void Main()
        {
            var stopWatch = new Stopwatch();

            var random = new Random();
            var numberList = Enumerable.Range(1, 1000000).OrderBy(i => random.Next());

            stopWatch.Start();
            DefaultParallelism(numberList.ToArray());
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for default parallelism: {0}", stopWatch.ElapsedMilliseconds);

            stopWatch.Reset();
            stopWatch.Start();
            LimitedParallelism(numberList.ToArray());
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for MaxDegreeOfParallelism: {0}", stopWatch.ElapsedMilliseconds);

            Console.Write("Complete. Press <ENTER> to exit.");
            Console.ReadKey();
        }

        private static void DefaultParallelism(Int32[] array)
        {
            Parallel.For(0, array.Length, i =>
                {
                    var temp = Math.Sqrt(array[i]);
                }
            );
        }

        
        private static void LimitedParallelism(Int32[] array)
        {
            var options = new ParallelOptions()
                {
                    MaxDegreeOfParallelism = 4
                };

            Parallel.For(0, array.Length, options, i =>
                {
                    var temp = Math.Sqrt(array[i]);
                });
        }
    }
}

