﻿using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace LoopExceptions
{
    class Program
    {
        static void Main()
        {
            try
            {
                var exceptionQueue = new ConcurrentQueue<Exception>();
                Parallel.For(0, 100, number =>
                {
                    try
                    {
                        if (number > 95)
                        {
                            throw new ArgumentException(String.Format("The number {0} is invalid. Must be smaller than 95.",number));
                        }
                        Console.WriteLine(number);
                    }
                    catch (Exception ex)
                    {
                          exceptionQueue.Enqueue(ex);  
                    }
                    if(exceptionQueue.Count > 0)
                        throw new AggregateException(exceptionQueue);
                });
            }
            catch (AggregateException aggregate)
            {
                foreach (var ex in aggregate.InnerExceptions)
                {
                    Console.WriteLine("An exception was caught: {0}",ex.InnerException.Message);
                }
            }
           Console.ReadLine();
        }
    }
}
