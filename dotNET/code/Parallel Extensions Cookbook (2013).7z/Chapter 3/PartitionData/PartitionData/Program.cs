﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PartitionData
{
    class Program
    {
        static void Main()
        {
            var stopWatch = new Stopwatch();

            var random = new Random();
            var numbers = Enumerable.Range(1, 10000000).OrderBy(i => random.Next()).ToArray();

            stopWatch.Start();
            NoPartitioning(numbers);
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for no partitioning: {0}", stopWatch.ElapsedMilliseconds);

            stopWatch.Reset();
            stopWatch.Start();
            DefaultPartitioning(numbers);
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for default partitioning: {0}", stopWatch.ElapsedMilliseconds);

            stopWatch.Reset();
            stopWatch.Start();
            CustomPartitioning(numbers);
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for custom partitioning: {0}", stopWatch.ElapsedMilliseconds);

            Console.Write("Complete. Press <ENTER> to exit.");
            Console.ReadKey();
        }
       
        private static void NoPartitioning(Int32[] numbers)
        {
            Parallel.ForEach(numbers, currentNumber =>
            {
                var temp = Math.Sqrt(currentNumber);
            });
        }

        private static void DefaultPartitioning(Int32[] numbers)
        {
            var partitioner = Partitioner.Create(numbers);
            Parallel.ForEach(partitioner, currentNumber =>
            {
                var temp = Math.Sqrt(currentNumber);
            });
        }

        private static void CustomPartitioning(Int32[] numbers)
        {
           var partitioner = Partitioner.Create(0, numbers.Count(), 100000);
            Parallel.ForEach(partitioner, range =>
            {
                for (var index = range.Item1; index < range.Item2; index++)
                {
                    var temp = Math.Sqrt(numbers[index]);
                }
            });
        }

    }
}
