﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace BreakALoop
{
    class Program
    {
        static void Main()
        {
            char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
            var client = new WebClient();
            const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
            client.Headers.Add("user-agent", headerText);
            var words = client.DownloadString(@"http://www.gutenberg.org/files/2009/2009.txt");
            var wordList = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToList();
            var loopResult = Parallel.ForEach(wordList, (parm, loopState) =>
            {
                if (parm.Equals("immutability"))
                {
                    Console.WriteLine(parm);
                    loopState.Break();
                }
            });
            Console.WriteLine("Loop LowestBreak Iteration : {0}", loopResult.LowestBreakIteration);
            Console.WriteLine("Loop Completed : {0}", loopResult.IsCompleted);
            Console.ReadLine();
        }
    }
}
