﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ParallelFor
{
    class Program
    {

        static void Main()
        {
            var stopWatch = new Stopwatch();

            var random = new Random();
            var numberList = Enumerable.Range(1, 10000000).OrderBy(i => random.Next());

            stopWatch.Start();
            SequentialLoop(numberList.ToArray());
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for sequential loop: {0}", stopWatch.ElapsedMilliseconds);

            stopWatch.Reset();
            stopWatch.Start();
            ParallelForLoop(numberList.ToArray());
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for parallel loop: {0}", stopWatch.ElapsedMilliseconds);

            Console.Write("Complete. Press <ENTER> to exit.");
            Console.ReadKey();
        }

        private static void SequentialLoop(Int32[] array)
        {
            for (var i = 0; i < array.Length; i++)
            {
                var temp = Math.Sqrt(array[i]);
            }
        }

        
        private static void ParallelForLoop(Int32[] array)
        {
            Parallel.For(0, array.Length, i =>
                {
                    var temp = Math.Sqrt(array[i]);
                }
            );
        }

    }
}
