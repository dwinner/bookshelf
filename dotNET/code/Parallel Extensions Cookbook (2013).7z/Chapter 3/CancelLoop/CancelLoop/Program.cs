﻿using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace CancelLoop
{
    class Program
    {
        static void Main()
        {
            var tokenSource = new CancellationTokenSource();
            var options = new ParallelOptions
            {
                CancellationToken = tokenSource.Token
            };

            Task.Factory.StartNew(() =>
            {
                Thread.Sleep(new TimeSpan(0,0,5));
                tokenSource.Cancel();
            });

            char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '"', '(', ')', '\u000A' };
            var client = new WebClient();
            const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
            client.Headers.Add("user-agent", headerText);
            var words = client.DownloadString(@"http://www.gutenberg.org/files/2009/2009.txt");
            var wordList = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries).Where(word => word.Length > 5).ToList();
            wordList.Sort();

            try
            {
                var loopResult = Parallel.ForEach(wordList, options, (currentWord, loopState) => Console.WriteLine(currentWord));
                Console.WriteLine("Loop Completed : {0}", loopResult.IsCompleted);
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Operation Cancelled");
            }
            catch (AggregateException)
            {
                Console.WriteLine("Operation Cancelled");
            }
            Console.ReadLine();
        }
    }
}
