﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ParallelForEach
{
    class Program
    {
        static void Main()
        {
            var stopWatch = new Stopwatch();

            var random = new Random();
            var numberList = Enumerable.Range(1, 10000000).OrderBy(i => random.Next());

            stopWatch.Start();
            SequentialLoop(numberList);
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for sequential loop: {0}", stopWatch.ElapsedMilliseconds);

            stopWatch.Reset();
            stopWatch.Start();
            ParallelForLoop(numberList);
            stopWatch.Stop();
            Console.WriteLine("Time in milliseconds for parallel loop: {0}", stopWatch.ElapsedMilliseconds);

            Console.Write("Complete. Press <ENTER> to exit.");
            Console.ReadKey();
        }

        private static void SequentialLoop(IEnumerable<int> numberList)
        {
            foreach (var currentNumber in numberList)
            {
                var temp = Math.Log(currentNumber);
            }
        }


        private static void ParallelForLoop(IEnumerable<int> numberList)
        {
            Parallel.ForEach(numberList, currentNumber =>
                {
                    var temp = Math.Log(currentNumber);
                }
            );
        }
    }
}
