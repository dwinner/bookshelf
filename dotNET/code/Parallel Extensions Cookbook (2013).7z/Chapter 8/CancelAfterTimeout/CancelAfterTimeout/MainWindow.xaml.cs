﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Net.Http;

namespace CancelAfterTimeout
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
        CancellationTokenSource tokenSource;

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void StartButton_Click(object sender, RoutedEventArgs e)
        {
            StartButton.IsEnabled = false;
            try
            {
                tokenSource = new CancellationTokenSource();
                var timeoutPeriod = int.Parse(TextTimeout.Text);
                tokenSource.CancelAfter(timeoutPeriod);                
                await GetWordCount(tokenSource.Token);                                
            }
            catch (OperationCanceledException)
            {
                TextResult.Text += "The operation was cancelled. \n";
            }
            catch (Exception)
            {
                TextResult.Text += "The operation failed to complete due to an exception. \n";
            }
            finally
            {
                StartButton.IsEnabled = true;
            }
        }

        async Task GetWordCount(CancellationToken token)
        {
            TextResult.Text += "Getting the word count for Origin of Species...\n";
            var client = new HttpClient();
            await Task.Delay(500);
            HttpResponseMessage response = await client.GetAsync(@"http://www.gutenberg.org/files/2009/2009.txt",token);
            var wordsTask = response.Content.ReadAsStringAsync();
            var words = await wordsTask;
            var wordArray = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            TextResult.Text += String.Format("Origin of Species word count: {0}", wordArray.Count());
        }
    }
}
