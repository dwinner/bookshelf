﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace AsyncExceptions
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void StartButton_Click(object sender, RoutedEventArgs e)
        {            
            try
            {
                var result = await GetWordCountAsync();
                ResultsTextBlock.Text += String.Format("Origin of Species word count: {0}", result);
            }
            catch(Exception ex)
            {
                ResultsTextBlock.Text += String.Format("An error has occurred: {0} \n", ex.Message);
            }            
            
        }

        public async Task<int> GetWordCountAsync()
        {
            ResultsTextBlock.Text += "Getting the word count for Origin of Species...\n";
            var client = new HttpClient();            
            try
            {
                var bookContents = await client.GetStringAsync(@"http://www.gutenberg.org/files/2009/No_Book_Here.txt");
                var wordArray = bookContents.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                return wordArray.Count();
            }
            catch (Exception ex)
            {
                ResultsTextBlock.Text += String.Format("An error has occurred: {0} \n", ex.Message);
                return 0;
            }
            finally
            {
                client.Dispose();
            }
            
        }
    }
}
