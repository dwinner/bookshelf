﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace AsyncWhenAll
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
        const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void StartButton_Click(object sender, RoutedEventArgs e)
        {
            
            TextResult.Text = "Started downloading books...\n";
            Task countTask = GetWordCount();
            await countTask;            
        }

        public async Task GetWordCount()
        {            
            var urlList = GetBookUrls();
            var wordCountQuery = from book in urlList select ProcessBook(book);
            Task<KeyValuePair<string,int>>[] wordCountTasks = wordCountQuery.ToArray();
            KeyValuePair<string, int>[] wordCounts = await Task.WhenAll(wordCountTasks);
            foreach (var book in wordCounts)
            {
                TextResult.Text += String.Format("Finished processing {0} : Word count {1} \n", book.Key, book.Value);
            }
        }

        private async Task<KeyValuePair<string, int>> ProcessBook(KeyValuePair<string,string> book)
        {
            var client = new HttpClient();
            Task<string> task = client.GetStringAsync(book.Value);
            var words = await task;
            var wordArray = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            return new KeyValuePair<string,int>(book.Key,wordArray.Count());

        }

        private List<KeyValuePair<string,string>> GetBookUrls()
        {
            var urlList = new List<KeyValuePair<string,string>>
            {
                new KeyValuePair<string,string>("Origin of Species","http://www.gutenberg.org/files/2009/2009.txt"),
                new KeyValuePair<string,string>("Beowulf","http://www.gutenberg.org/files/16328/16328-8.txt"),
                new KeyValuePair<string,string>("Ulysses","http://www.gutenberg.org/files/4300/4300.txt")
            };
            return urlList;
        }
    }
}
