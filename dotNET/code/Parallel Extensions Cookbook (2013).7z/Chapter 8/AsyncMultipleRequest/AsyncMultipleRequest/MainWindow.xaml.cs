﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Net.Http;

namespace AsyncMultipleRequest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void StartButton_Click(object sender, RoutedEventArgs e)
        {
            TextResult.Text += "Started downloading books...\n";
            await GetMultipleWordCount();
            TextResult.Text += "Finished downloading books...\n";
        }

        public async Task GetMultipleWordCount()
        {
            var client = new HttpClient();
            var results = new List<KeyValuePair<string, int>>();
            var urlList = GetBookUrls();
            var bookQuery = from book in urlList select ProcessBook(book, client);
            var bookTasks = bookQuery.ToList();
            while (bookTasks.Count > 0)
            {
                var firstFinished = await Task.WhenAny(bookTasks);
                bookTasks.Remove(firstFinished);
                var thisBook = await firstFinished;
                TextResult.Text += String.Format("Finished downloading {0}. Word count: {1}\n", 
                    thisBook.Key, 
                    thisBook.Value);
            }
        }

        async Task<KeyValuePair<string,int>> ProcessBook(KeyValuePair<string,string> book, HttpClient client)
        {
            var bookContents = await client.GetStringAsync(book.Value);
            var wordArray = bookContents.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            return new KeyValuePair<string,int>(book.Key,wordArray.Count());
        }        
        
        private List<KeyValuePair<string, string>> GetBookUrls()
        {
            var urlList = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string,string>("Origin of Species",
                            "http://www.gutenberg.org/files/2009/2009.txt"),
                new KeyValuePair<string,string>("Beowulf",
                            "http://www.gutenberg.org/files/16328/16328-8.txt"),
                new KeyValuePair<string,string>("Ulysses",
                            "http://www.gutenberg.org/files/4300/4300.txt")
            };
            return urlList;
        }
    }
}
