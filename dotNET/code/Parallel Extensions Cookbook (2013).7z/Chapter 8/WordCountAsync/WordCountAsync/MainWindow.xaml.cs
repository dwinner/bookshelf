﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace WordCountAsync
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void StartButton_Click(object sender, RoutedEventArgs e)
        {
            var result = await GetWordCountAsync();
            TextResults.Text += String.Format("Origin of Species word count: {0}",result);
        }

        public async Task<int> GetWordCountAsync()
        {
            TextResults.Text += "Getting the word count for Origin of Species...\n";
            var client = new HttpClient();
            var bookContents = await client.GetStringAsync(@"http://www.gutenberg.org/files/2009/2009.txt");
            var wordArray = bookContents.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            return wordArray.Count();           
        }
    }
}
