﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

namespace CustomAwaiter
{
    public static class DoubleExtensionMethods
    {
        public static DoubleAwaiter GetAwaiter(this double MyDouble, int power)
        {
            return new DoubleAwaiter(MyDouble, power);
        }
    }
    
    
    public class DoubleAwaiter: INotifyCompletion
    {
        private double _MyValue;
        private int _power;

        public DoubleAwaiter(double MyValue, int power)
        {
            this._MyValue = MyValue;
            this._power = power;
            IsCompleted = false;
        }

        public bool IsCompleted { get; set; }
        
        public DoubleAwaiter GetAwaiter()
        {
            return this;
        }

        public double GetResult()
        {
            return _MyValue;
        }

        public void OnCompleted(Action continuation)
        {
            this._MyValue = Math.Pow(_MyValue, _power);
            IsCompleted = true;
            continuation();
        }        
    }
}
