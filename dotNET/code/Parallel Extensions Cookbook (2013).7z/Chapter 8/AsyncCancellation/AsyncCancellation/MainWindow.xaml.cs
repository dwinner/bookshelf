﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace AsyncCancellation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
        CancellationTokenSource cts;

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void StartButton_Click(object sender, RoutedEventArgs e)
        {
            cts = new CancellationTokenSource();            
            try
            {
                var result = await GetWordCountAsync(cts.Token);
                TextResult.Text += String.Format("Origin of Species word count: {0}", result);
            }
            catch (OperationCanceledException)
            {
                TextResult.Text += "Download cancelled.\n";
            }
            catch (Exception ex)
            {
                TextResult.Text += String.Format("An error has occurred: {0} \n", ex.Message);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (cts != null)
            {
                cts.Cancel();
            }
        }

        public async Task<int> GetWordCountAsync(CancellationToken ct)
        {
            TextResult.Text += "Getting the word count for Origin of Species...\n";            
            var client = new HttpClient();
            await Task.Delay(500);
            try
            {
                HttpResponseMessage response = await client.GetAsync(@"http://www.gutenberg.org/files/2009/2009.txt", ct);
                var words = await response.Content.ReadAsStringAsync();
                var wordArray = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                return wordArray.Count();
            }
            finally
            {
                client.Dispose();
            }

        }
    }
}
