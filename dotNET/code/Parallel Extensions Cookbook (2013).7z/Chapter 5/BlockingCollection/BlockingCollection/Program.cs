﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace BlockingCollection
{
    class Program
    {
        static void Main()
        {
            var data = Enumerable.Range(0, 100);
            var numbers = new BlockingCollection<int>(100);
            
            // A simple blocking producer 
            Task.Factory.StartNew( ()=>
            {
                foreach (var item in data)
                {
                    numbers.Add(item);
                    Console.WriteLine("Adding:{0} Item Count={1}", item, numbers.Count);
                }
                numbers.CompleteAdding();
            });

            // A simple blocking consumer.
            Task.Factory.StartNew(() =>
            {
                int item = -1;
                while (!numbers.IsCompleted)
                {
                    try
                    {
                        item = numbers.Take();
                    }
                    catch (InvalidOperationException)
                    {
                        Console.WriteLine("Nothing to take");
                        break;
                    }
                    Console.WriteLine("Taking:{0} ", item);
                    // wait for a bit
                    Thread.SpinWait(1000);
                }

                Console.WriteLine("\rNo more items to take.");
            });

            Console.ReadLine();
        }
    }
}
