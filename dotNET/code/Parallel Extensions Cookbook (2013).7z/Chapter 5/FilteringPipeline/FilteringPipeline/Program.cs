﻿using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace FilteringPipeline
{

    class Program
    {

        public static void Main()
        {
            //Generate the source data.
            var source = new BlockingCollection<int>[3];
            for (int i = 0; i < source.Length; i++)
                source[i] = new BlockingCollection<int>(100);

            Parallel.For(0, source.Length * 100, (data) =>
            {
                int item = BlockingCollection<int>.TryAddToAny(source, data);
                if (item >= 0)
                    Console.WriteLine("added {0} to source data", data);
            });

            foreach (var array in source)
                array.CompleteAdding();

            // calculate the square 
            var calculateFilter = new PipelineFilter<int, int>
            (
                source,
                (n) => n * n,
                "calculateFilter"
             );

            //Convert ints to strings
            var convertFilter = new PipelineFilter<int, string>
            (
                calculateFilter.m_outputData,
                (s) => String.Format("{0}", s),
                "convertFilter"
             );

            // Displays the results
            var displayFilter = new PipelineFilter<string, string>
            (
                convertFilter.m_outputData,
                (s) => Console.WriteLine("The final result is {0}", s),
                "displayFilter");

            // Start the pipeline
            try
            {
                Parallel.Invoke(
                             () => calculateFilter.Run(),
                             () => convertFilter.Run(),
                             () => displayFilter.Run()
                         );
            }
            catch (AggregateException aggregate)
            {
                foreach (var exception in aggregate.InnerExceptions)
                    Console.WriteLine(exception.Message + exception.StackTrace);
            }

            Console.ReadLine();
        }

    }  
}
