﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CancelOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            var data = Enumerable.Range(0, 100);
            var numbers = new BlockingCollection<int>(100);
            var tokenSource = new CancellationTokenSource();
            var token = tokenSource.Token;

            // A simple blocking producer 
            Task.Factory.StartNew(() =>
            {
                foreach (var item in data)
                {
                    try
                    {
                        numbers.TryAdd(item,5,token);
                        Console.WriteLine("Adding:{0} Item Count={1}", item, numbers.Count);
                    }
                    catch(OperationCanceledException)
                    {
                        Console.WriteLine("Adding operation has been cancelled");
                        numbers.CompleteAdding();
                        break;
                    }
                }
                numbers.CompleteAdding();
            },token);


            // A simple blocking consumer.
            Task.Factory.StartNew(() =>
            {
                int item = -1;
                
                while (!numbers.IsCompleted)
                {
                    try
                    {
                        numbers.TryTake(out item,5,token);
                    }
                    catch (OperationCanceledException)
                    {
                        Console.WriteLine("Take operation has been cancelled");
                        break;
                    }
                    Console.WriteLine("Taking:{0} ", item);
                    // wait for a bit
                    Thread.SpinWait(10000);
                }
                Console.WriteLine("\rNo more items to take.");
            },token);

            Thread.SpinWait(2000000);
            tokenSource.Cancel();
            Console.ReadLine();
        }
    }
}
