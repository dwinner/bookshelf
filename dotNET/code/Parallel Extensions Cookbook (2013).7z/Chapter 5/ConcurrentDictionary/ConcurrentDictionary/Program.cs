﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConcurrentDictionary
{
    class Program
    {
        static void Main()
        {
            var dictionary = new ConcurrentDictionary<string, int>();
            dictionary["A"] = 1;
            dictionary["B"] = 2;
            dictionary["C"] = 3;
            dictionary["D"] = 4;
            dictionary["E"] = 5;
            dictionary["F"] = 6;
            dictionary["G"] = 7;
            dictionary["H"] = 8;
            dictionary["I"] = 9;
            dictionary["J"] = 10;
            dictionary["K"] = 11;
            dictionary["L"] = 12;
            dictionary["M"] = 13;
            dictionary["N"] = 14;
            dictionary["O"] = 15;

            // update dictionary on a separate thread
            Task.Factory.StartNew(() =>
                {
                    foreach (var pair in dictionary)
                    {
                        var newValue = pair.Value + 1;
                        dictionary.TryUpdate(pair.Key,newValue,pair.Value);
                        Console.WriteLine("Updated key: {0} value:{1}", pair.Key, newValue);
                    }   
                }
            );            
            
            Task.Factory.StartNew(() =>
            {
                foreach (var pair in dictionary)
                 {
                     Console.WriteLine("Reading key: {0} value:{1}",pair.Key,pair.Value);
                 }
            });            

            Console.ReadLine();

        }
    }
}
