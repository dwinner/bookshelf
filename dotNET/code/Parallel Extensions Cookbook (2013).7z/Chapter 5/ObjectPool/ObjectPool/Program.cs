﻿using System;
using System.Text;
using System.Threading.Tasks;

namespace ObjectPool
{
    class Program
    {
        static void Main(string[] args)
        {
            var pool = new ConcurrentObjectPool<StringBuilder>(()=>new StringBuilder("Pooled Object created by objectInitializer"));

            var task1 = Task.Factory.StartNew(() =>
            {
                for (var index = 0; index < 10; index++)
                {
                    StringBuilder newObject = new StringBuilder(string.Concat("Pooled object", index.ToString()));
                    Console.WriteLine("Putting pooled object: {0}", index.ToString());
                    pool.PutObject(newObject);
                }
            });

            
            task1.ContinueWith((antecedent)=>
            {
                for (var index = 0; index < 10; index++)
                {
                    var pooledObject = pool.GetObject();
                    Console.WriteLine("First Task: {0}", pooledObject.ToString());                    
                }
            });

            task1.ContinueWith((antecedent) =>
            {
                for (var index = 0; index < 10; index++)
                {
                    var pooledObject = pool.GetObject();
                    Console.WriteLine("Second Tasks: {0}", pooledObject.ToString());
                }
            });

            
           

            Console.ReadLine();
        }        
    }
}
