﻿using System;
using System.Collections.Concurrent;

namespace ObjectPool
{
    public class ConcurrentObjectPool<T>
    {
        private ConcurrentStack<T> _objects;
        private Func<T> _objectInitializer;

        public ConcurrentObjectPool(Func<T> objectInitializer)
        {
            _objects = new ConcurrentStack<T>();
            _objectInitializer = objectInitializer;
        }

        public T GetObject()
        {
            T item;
            if (_objects.TryPop(out item)) return item;
            return _objectInitializer();
        }

        public void PutObject(T item)
        {
            _objects.Push(item);
        }
    }

}