﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Concurrent;

namespace EnumerateCollection
{
    class Program
    {
        static void Main()
        {
            var numbers = Enumerable.Range(0, 100);
            var result = new BlockingCollection<long>(1000);

            //Producer
            Task.Factory.StartNew(() =>
                {
                    foreach (var item in numbers)
                    {
                        result.Add(item);
                        Console.WriteLine("Adding:{0} Item Count={1}", item, result.Count());
                    }
                    result.CompleteAdding();
                });
            Task.Factory.StartNew(() =>
                {
                    foreach (var item in result.GetConsumingEnumerable())
                    {                        
                         Console.Write("\nConsuming item: {0}", item);                       
                    }
                    
                });

            Console.ReadLine();
        }
    }
}
