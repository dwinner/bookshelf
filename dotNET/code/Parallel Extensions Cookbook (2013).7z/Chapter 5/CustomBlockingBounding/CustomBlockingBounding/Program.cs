﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace CustomBlockingBounding
{  

    public class TestBlockingCollection
    {
        static void Main()
        {
            var queue = new PriorityQueue<QueuePriorityLevel, int>();
            var bc = new BlockingCollection<KeyValuePair<QueuePriorityLevel, int>>(queue);
            var tasks = new List<Task>();

            var producer = Task.Factory.StartNew(() =>
            {
                Random r = new Random();
                int itemsToAdd = 50;
                int count = 0;
                for (int i = 0; i < itemsToAdd; i++ )
                {

                    Thread.SpinWait(10000);
                    // Generate random priority level
                    QueuePriorityLevel[] values = (QueuePriorityLevel[])Enum.GetValues(typeof(QueuePriorityLevel));
                    var priority = values[new Random().Next(0, values.Length)];                    
                    var item = new KeyValuePair<QueuePriorityLevel, int>(priority, count++);
                    bc.Add(item);
                    Console.WriteLine("added priority {0}, data={1}", priority, item.Value);
                }
                Console.WriteLine("Producer is finished.");
             }).ContinueWith( (antecedent)=>
                 {
                     bc.CompleteAdding();
                 });

            //wait for a bit
            Thread.SpinWait(100000);

            var consumer = Task.Factory.StartNew(() =>
            {
                while (!bc.IsCompleted )
                {
                   KeyValuePair<QueuePriorityLevel, int> item = new KeyValuePair<QueuePriorityLevel, int>();
                    bool success = false;
                    success = bc.TryTake(out item);
                    if (success)
                    {
                        Console.WriteLine("removed Priority = {0} data = {1} Collection Count= {2}", item.Key, item.Value, bc.Count);
                    }
                    else
                        Console.WriteLine("No items remaining. count = {0}", bc.Count);
                }
                Console.WriteLine("Exited consumer loop");
            });
            tasks.Add(producer);
            tasks.Add(consumer);

            try
            {
                Task.WaitAll(tasks.ToArray());
            }
            
            catch (AggregateException ae)
            {
                foreach (var v in ae.InnerExceptions)
                    Console.WriteLine(v.Message);
            }

            Console.ReadLine();
        }
    }
}

