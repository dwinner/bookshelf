﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections;
using System;
using System.Threading;

namespace CustomBlockingBounding
{
    public class PriorityQueue<PriorityLevel, TValue>: IProducerConsumerCollection<KeyValuePair<QueuePriorityLevel, TValue>>
    {
        private ConcurrentQueue<KeyValuePair<QueuePriorityLevel, TValue>> _lowPriotityQueue = null;
        private ConcurrentQueue<KeyValuePair<QueuePriorityLevel, TValue>> _mediumPriotityQueue = null;
        private ConcurrentQueue<KeyValuePair<QueuePriorityLevel, TValue>> _highPriotityQueue = null;
        private ConcurrentQueue<KeyValuePair<QueuePriorityLevel, TValue>>[] _queues = null;
        private int _count = 0;
        
        public PriorityQueue()
        {
            _lowPriotityQueue = new ConcurrentQueue<KeyValuePair<QueuePriorityLevel,TValue>>();
            _mediumPriotityQueue = new ConcurrentQueue<KeyValuePair<QueuePriorityLevel,TValue>>();
            _highPriotityQueue = new ConcurrentQueue<KeyValuePair<QueuePriorityLevel,TValue>>();
            _queues = new ConcurrentQueue<KeyValuePair<QueuePriorityLevel, TValue>>[3]
                {
                    _lowPriotityQueue,
                    _mediumPriotityQueue,
                    _highPriotityQueue
                };
        }

        public void CopyTo(KeyValuePair<QueuePriorityLevel, TValue>[] array, int index)
        {
            if (array == null) throw new ArgumentNullException();

            int remaining = array.Length;
            KeyValuePair<QueuePriorityLevel, TValue>[] temp = this.ToArray();
            for (int i = 0; i < array.Length && i < temp.Length; i++)
                array[i] = temp[i];
        }

        public KeyValuePair<QueuePriorityLevel, TValue>[] ToArray()
        {
            KeyValuePair<QueuePriorityLevel, TValue>[] result;

            lock (_queues)
            {
                result = new KeyValuePair<QueuePriorityLevel, TValue>[this.Count];
                int index = 0;
                foreach (var q in _queues)
                {
                    if (q.Count > 0)
                    {
                        q.CopyTo(result, index);
                        index += q.Count;
                    }
                }
                return result;
            }
        }

        public bool TryAdd(KeyValuePair<QueuePriorityLevel, TValue> item)
        {
            int priority = (int) item.Key;
            _queues[priority].Enqueue(item);
            Interlocked.Increment(ref _count);
            return true;
        }

        public bool TryTake(out KeyValuePair<QueuePriorityLevel, TValue> item)
        {
            bool success = false;

            for (int i = 0; i <= 2; i++)
            {
                lock (_queues)
                {
                    success = _queues[i].TryDequeue(out item);
                    if (success)
                    {
                        Interlocked.Decrement(ref _count);
                        return true;
                    }
                }
            }

            item = new KeyValuePair<QueuePriorityLevel, TValue>(0, default(TValue));
            return false;
        }

        public IEnumerator<KeyValuePair<QueuePriorityLevel, TValue>> GetEnumerator()
        {
            for (int i = 0; i <= 2; i++)
            {
                foreach (var item in _queues[i])
                    yield return item;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public void CopyTo(System.Array array, int index)
        {
            throw new System.NotImplementedException();
        }

        public int Count
        {
            get { return _count; }
        }

        public bool IsSynchronized
        {
            get { throw new System.NotImplementedException(); }
        }

        public object SyncRoot
        {
            get { throw new System.NotImplementedException(); }
        }
    }

    public enum QueuePriorityLevel
    {
        High = 0,
        Medium = 1,
        Low = 2
    }
}
