﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ConcurrentStack
{
    class Program
    {
        static void Main(string[] args)
        {
            var data = Enumerable.Range(0, 100);
            ConcurrentStack<int> stack = new ConcurrentStack<int>();

            // producer 
            Task.Factory.StartNew(() =>
            {
                foreach (var item in data)
                {
                    stack.Push(item);
                    Console.WriteLine("Pushing item onto stack:{0} Item Count={1}", item, stack.Count);
                }
            });
            
            //consumer
            Task.Factory.StartNew(() =>
            {
                Thread.SpinWait(1000000);
                while (!stack.IsEmpty)
                {
                    int result = 0;
                    stack.TryPop(out result);
                    Console.WriteLine("Popping item from stack:{0} Item Count={1}", result, stack.Count);
                }
            });

           Console.ReadLine();
        }
    }
}
