﻿using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Continuation1
{
    class Program
    {
        private static void Main()
        {
            try
            {
                var client = new WebClient();
                const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
                client.Headers.Add("user-agent", headerText);
                
                Task.Factory.StartNew(() =>
                    {
                        Console.WriteLine("Antecedent running.");
                        char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };                        
                        var words = client.DownloadString(@"http://www.gutenberg.org/files/2009/2009.txt");
                        var wordArray = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                        Console.WriteLine("Word count for Origin of Species: {0}", wordArray.Count());
                    }
                ).ContinueWith(antecedent =>
                    {
                        Console.WriteLine("Continuation running");
                        client.Dispose();
                    }).Wait();

               Console.WriteLine("Complete. Please hit <Enter> to exit.");
               Console.ReadLine();
            }
            catch (AggregateException aEx)
            {
                foreach (var ex in aEx.InnerExceptions)
                {
                    Console.WriteLine("An exception has occured: {0}" + ex.Message);
                }
            }
        }
    }
}
