﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Continuation7
{
    class Program
    {
        static void Main()
        {

            try
            {
                var producer = Task.Factory.StartNew(() =>
                {
                    char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
                    var client = new WebClient();
                    const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
                    client.Headers.Add("user-agent", headerText);
                    try
                    {
                        var words = client.DownloadString(@"http://www.gutenberg.org/files/2009/2009.txt");
                        var wordArray = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                        Console.WriteLine("Word count for Origin of Species: {0}", wordArray.Count());
                        Console.WriteLine();
                        return wordArray;
                    }
                    finally
                    {
                        client.Dispose();
                    }
                });
                Task<string[]> consumer1 = producer.ContinueWith(antecedent =>
                    {
                        var wordsByUsage =
                          antecedent.Result.Where(word => word.Length > 5)
                                    .GroupBy(word => word)
                                    .OrderByDescending(grouping => grouping.Count())
                                    .Select(grouping => grouping.Key);
                        var commonWords = (wordsByUsage.Take(5)).ToArray();
                        Console.WriteLine("The 5 most commonly used words in Origin of Species:");
                        Console.WriteLine("----------------------------------------------------");
                        foreach (var word in commonWords)
                        {
                            Console.WriteLine(word);
                        }
                        Console.WriteLine();
                        return antecedent.Result;
                    }, TaskContinuationOptions.OnlyOnRanToCompletion);

                Task consumer2 = consumer1.ContinueWith(antecedent =>
                        {
                            var longestWord = (antecedent.Result.OrderByDescending(w => w.Length)).First();
                            Console.WriteLine("The longest word is: {0}", longestWord);
                        }, TaskContinuationOptions.OnlyOnRanToCompletion);
                consumer2.Wait();
            }
            catch (AggregateException aEx)
            {
                foreach (var ex in aEx.InnerExceptions)
                {
                    Console.WriteLine("An exception has occured: {0}", ex.Message);
                }
            }
            finally
            {
                Console.WriteLine();
                Console.WriteLine("Complete. Please hit <Enter> to exit.");
                Console.ReadLine();
            }
            
        }
    }
}
