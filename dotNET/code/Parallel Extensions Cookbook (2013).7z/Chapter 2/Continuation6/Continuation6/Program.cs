﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Continuation6
{
    class Program
    {
        static void Main()
        {
            var tokenSource = new CancellationTokenSource();
            var token = tokenSource.Token;

            try
            {
                var task1 = Task.Factory.StartNew(state =>
                    {
                        Console.WriteLine("Task has started.");
                        var result = new List<Int32>();
                        for (var i = 0; i < (Int32) state; i++)
                        {
                           token.ThrowIfCancellationRequested();
                            result.Add(i);
                            Thread.Sleep(100); //sleep to simulate some work
                        }
                        return result;
                    }, 5000,token);

                task1.ContinueWith(antecedent =>
                    {
                        Console.WriteLine("Continuation has started.");
                        var antecedentResult = antecedent.Result;
                        var squares = new List<int>();
                        foreach (var value in antecedentResult)
                        {
                            token.ThrowIfCancellationRequested();
                            squares.Add(value*value);
                            Thread.Sleep(100);//sleep to simulate some more work
                        }
                        return squares;
                    },token);

                Thread.Sleep(2000); //wait for 2 seconds
                tokenSource.Cancel();
                task1.Wait();
            }
            catch (AggregateException aEx)
            {
                foreach (var ex in aEx.InnerExceptions)
                {
                    Console.WriteLine("An exception has occured: " + ex.Message);
                }
            }
            finally
            {
                tokenSource.Dispose();
            }
            Console.WriteLine("Complete. Press enter to exit.");            
            Console.ReadLine();
        }
    }
}
