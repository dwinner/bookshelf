﻿using System;
using System.Net;
using System.Threading.Tasks;

namespace Continuation5
{
    class Program
    {
        static void Main()
        {
            Task task1 = Task.Factory.StartNew(() =>
                {
                    Console.WriteLine("Starting the task.");
                    var client = new WebClient();
                    const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
                    client.Headers.Add("user-agent", headerText);
                    try
                    {
                        var book = client.DownloadString(@"http://www.gutenberg.org/files/2009/2009.txt");
                        var ex = new WebException("Unable to download book contents");
                        throw ex;
                    }
                    finally
                    {
                        client.Dispose();
                        Console.WriteLine("WebClient disposed.");
                    }
                });

            task1.ContinueWith(antecedent=> Console.WriteLine("The task ran to completion."),TaskContinuationOptions.OnlyOnRanToCompletion);

            task1.ContinueWith(antecedent =>
                {
                    Console.WriteLine("The task faulted.");
                    var aEx = antecedent.Exception;
                    if (aEx != null)
                        foreach (var ex in aEx.InnerExceptions)
                        {
                            Console.WriteLine("Handled Exception: {0}",ex.Message);
                        }
                }, TaskContinuationOptions.OnlyOnFaulted);

            Console.ReadLine();
        }
    }
}
