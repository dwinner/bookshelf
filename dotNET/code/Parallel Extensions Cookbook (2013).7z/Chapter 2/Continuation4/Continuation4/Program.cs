﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Continuation4
{
    class Program
    {
        static void Main()
        {
            var tokenSource1 = new CancellationTokenSource();
            var token1 = tokenSource1.Token;

            var tokenSource2 = new CancellationTokenSource();
            var token2 = tokenSource2.Token;
            
            try
            {
                var task1 = Task.Factory.StartNew(() =>
                {
                    Console.WriteLine("Task #1 is running.");
                    //wait a bit
                    Thread.Sleep(2000);
                }, token1);

                task1.ContinueWith(antecedent => Console.WriteLine("Task #1 completion continuation."), TaskContinuationOptions.OnlyOnRanToCompletion);

                task1.ContinueWith(antecedent => Console.WriteLine("Task #1 cancellation continuation."), TaskContinuationOptions.OnlyOnCanceled);
                
                var task2 = Task.Factory.StartNew(() =>
                {
                    Console.WriteLine("Task #2 is running.");
                    //wait a bit
                    Thread.Sleep(2000);
                }, token2);

                task2.ContinueWith(antecedent => Console.WriteLine("Task #2 completion continuation."), TaskContinuationOptions.OnlyOnRanToCompletion);

                task2.ContinueWith(antecedent => Console.WriteLine("Task #2 cancellation continuation."), TaskContinuationOptions.OnlyOnCanceled);
            }
            catch (AggregateException aEx)
            {
                foreach (var ex in aEx.InnerExceptions)
                {
                    Console.WriteLine("Caught exception: {0}", ex.Message);
                }
            }
            tokenSource2.Cancel();
            Console.ReadLine();
        }
    }
}
