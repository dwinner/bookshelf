﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Continuation3
{
    sealed class Program
    {
        static void Main()
        {
            char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
            const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
            var dictionary = new Dictionary<string, string>
                {
                    {"Origin of Species", "http://www.gutenberg.org/files/2009/2009.txt"},
                    {"Beowulf", "http://www.gutenberg.org/files/16328/16328-8.txt"},
                    {"Ulysses", "http://www.gutenberg.org/files/4300/4300.txt"}
                };
            try
            {
                var tasks = new List<Task<KeyValuePair<string, int>>>();

                foreach (var pair in dictionary)
                {
                    tasks.Add(Task.Factory.StartNew(stateObj =>
                    {
                        var taskData = (KeyValuePair<string, string>)stateObj;
                        Console.WriteLine("Starting task for {0}", taskData.Key);
                        var client = new WebClient();
                        client.Headers.Add("user-agent", headerText);
                        var words = client.DownloadString(taskData.Value);
                        var wordArray = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                        return new KeyValuePair<string, int>(taskData.Key, wordArray.Count());
                    }, pair));
                }
                Task.Factory.ContinueWhenAll(tasks.ToArray(), antecedents =>
                {
                    foreach (var antecedent in antecedents)
                    {
                        Console.WriteLine("Book Title: {0}", antecedent.Result.Key);
                    Console.WriteLine("Word count: {0}", antecedent.Result.Value);
                    }
                    
                }).Wait();
            }
            catch (AggregateException aEx)
            {
                foreach (var ex in aEx.InnerExceptions)
                {
                    Console.WriteLine("An exception has occured: {0}" + ex.Message);
                }
            }
            Console.WriteLine("Complete. Press <Enter> to exit.");
            Console.ReadLine();
        }
    }
}
