﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace WordCount5
{
    class Program
    {
        static void Main()
        {
            var lazyCount = new Lazy<Task<int>>(() =>
                //Task declaration and body go here
                 Task<int>.Factory.StartNew(() =>
                     {
                         Console.WriteLine("Executing the task.");
                         char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
                         const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
                         const string uri = "http://www.gutenberg.org/files/2009/2009.txt";
                         var client = new WebClient();
                         client.Headers.Add("user-agent", headerText);
                         var words = client.DownloadString(uri);
                         var wordArray = words.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                         return wordArray.Count();
                     }
                 )
             );

            Console.WriteLine("Calling the lazy variable");
            Console.WriteLine("Origin of species word count: {0}",lazyCount.Value.Result );
            Console.WriteLine("Press <Enter> to exit.");
            Console.ReadLine();
        }
    }
}