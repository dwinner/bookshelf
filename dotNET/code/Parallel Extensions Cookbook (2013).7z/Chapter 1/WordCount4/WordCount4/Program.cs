﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace WordCount4
{
    class Program
    {
        static void Main()
        {
            char[] delimiters = { ' ', ',', '.', ';', ':', '-', '_', '/', '\u000A' };
            const string headerText = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";

             Task parent = Task.Factory.StartNew(() =>
                {
                    Console.WriteLine("Parent task starting");
                    const string uri = "http://www.gutenberg.org/files/2009/2009.txt";
                    var client = new WebClient();
                    client.Headers.Add("user-agent", headerText);
                    var book = client.DownloadString(uri);
                    var wordArray = book.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                    Task.Factory.StartNew(()=>
                        {
                            Console.WriteLine("Child task starting");
                            Console.WriteLine("Word count for Origin of Species: {0}",wordArray.Count());
                            Console.WriteLine("Attached child task completed.");
                        },TaskCreationOptions.AttachedToParent
                        );
                }
              );
            parent.Wait();
            Console.WriteLine("Parent task completed.");
            Console.WriteLine("Press <Enter> to exit.");
            Console.ReadLine();
        }
    }
}

