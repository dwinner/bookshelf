﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PreserveOrder
{
    class Program
    {
        private static void Main()
        {
            var source1 = Enumerable.Range(1, 100000);
            UnorderedQuery(source1);

            Console.WriteLine();

            var source2 = Enumerable.Range(1, 100000);
            OrderedQuery(source2);

            Console.ReadLine();
        }

        private static void UnorderedQuery(IEnumerable<int> source)
        {
            Console.WriteLine("Unordered results");
            var query = (from numbers in source.AsParallel()
                         where numbers%5 == 0
                         select numbers).Take(10);

            foreach (var number in query)
                Console.WriteLine(number);
        }

        private static void OrderedQuery(IEnumerable<int> source)
        {
            Console.WriteLine("Ordered results");
            var query = (from numbers in source.AsParallel().AsOrdered()
                         where numbers % 5 == 0
                         select numbers).Take(10);

            foreach (var number in query)
                Console.WriteLine(number);
        }
    }
}