﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessResults
{
    class Program
    {
        static void Main(string[] args)
        {
            var result = new ConcurrentBag<Int32>();
            var source = Enumerable.Range(1, 100000);
            var query = (from numbers in source.AsParallel()
                         where numbers % 5 == 0
                         select numbers).Take(100);
            query.ForAll(r => 
                {
                    result.Add(r * r);
                });

            foreach (var value in result)
            {
                Console.WriteLine("Result squared: {0}", value);
            }
            Console.ReadLine();
        }
    }
}
