﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CancelQuery
{
    class Program
    {
        static void Main()
        {
            var tokenSource = new CancellationTokenSource();
            var random = new Random();
            var numberList = ParallelEnumerable.Range(1, 100000).OrderBy(i => random.Next());

            var results = numberList
                .AsParallel()
                .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                .WithCancellation(tokenSource.Token)
                .Select(number => Math.Pow(number, 2));

            // create a task that will wait for 1000 ms and then cancel the token
            Task.Factory.StartNew(() =>
            {
                Thread.Sleep(1000);
                tokenSource.Cancel();
                Console.WriteLine("Cancelling query.");
            });

            try
            {
                foreach (var number in results)
                {
                    Console.WriteLine("Result: {0}", number);
                }
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("The operation was cancelled");
            }
            catch (AggregateException aggregateException)
            {
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    Console.WriteLine("Handled exception: {0}",exception.Message);
                }
            }
            Console.ReadLine();

        }
    }
}
