﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace ForceParallel
{
    internal class Program
    {
        private static void Main()
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            NoForcedParallelism();
            stopWatch.Stop();
            Console.WriteLine("Query without forced parallelism ran in {0} ms.",stopWatch.ElapsedMilliseconds);
            stopWatch.Reset();
            stopWatch.Start();
            ForcedParallelism();
            stopWatch.Stop();
            Console.WriteLine("Query with forced parallelism ran in {0} ms.", stopWatch.ElapsedMilliseconds);
            Console.ReadLine();
        }

        private static void NoForcedParallelism()
        {
            Enumerable.Range(0, 1000).AsParallel()
                              .Where(x =>
                                  {
                                      Thread.SpinWait(1000000);
                                      return true;
                                  })
                              .Select((x, i) => i)
                              .ToArray();
        }

        private static void ForcedParallelism()
        {
            Enumerable.Range(0, 1000).AsParallel()
                              .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                              .Where(x =>
                              {
                                  Thread.SpinWait(1000000);
                                  return true;
                              })
                              .Select((x, i) => i)
                              .ToArray();
        }
    }
}
