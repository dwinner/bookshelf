﻿using System.Collections.Concurrent;
using System.Collections.Generic;

namespace CustomPartitioner
{
    internal class CustomPartitioner<T> : Partitioner<T>
    {
        private readonly T[] _source;

        public CustomPartitioner(T[] sourceData)
        {
            _source = sourceData;
        }

        /// <summary>
        /// Gets whether additional partitions can be created dynamically.
        /// </summary>
        /// <returns>
        /// true if the partitioner can create partitions dynamically as they are requested; 
        /// false if the it can only allocate partitions statically.
        /// </returns>
        public override bool SupportsDynamicPartitions
        {
            get
            {
                return false;
            }
        }

        public override IList<IEnumerator<T>> GetPartitions(int partitionCount)
        {
            IList<IEnumerator<T>> partitionedData = new List<IEnumerator<T>>();
            var items = _source.Length / partitionCount;
            for (var index = 0; index < partitionCount - 1; index++)
            {
                partitionedData.Add(GetItems(index * items, (index + 1) * items));
            }
            partitionedData.Add(GetItems((partitionCount - 1) * items, _source.Length));
            return partitionedData;
        }

        internal IEnumerator<T> GetItems(int start, int end)
        {
            for (var index = start; index < end; index++)
                yield return _source[index];
        }
    }
}
