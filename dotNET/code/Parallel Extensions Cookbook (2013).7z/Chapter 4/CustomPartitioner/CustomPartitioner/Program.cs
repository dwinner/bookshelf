﻿using System;
using System.Diagnostics;
using System.Linq;

namespace CustomPartitioner
{
    class Program
    {
        static void Main()
        {
            
            var random = new Random();
            var source = Enumerable.Range(1, 10000000).OrderBy(i => random.Next()).ToArray();

            // PLINQ with no partitioning
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            source.AsParallel()
                .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                .Select(item => Math.Sqrt(item));

            stopWatch.Stop();
            Console.WriteLine("PLINQ with no partioner ran in {0} ticks", stopWatch.ElapsedTicks );
                
            
            // PLINQ with custom partitioning
            var partitioner = new CustomPartitioner<int>(source);

            stopWatch.Reset();
            stopWatch.Start();

            partitioner.AsParallel()
                .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                .Select(item => Math.Sqrt(item));
            
            stopWatch.Stop();
            Console.WriteLine("PLINQ with custom partioner ran in {0} ticks", stopWatch.ElapsedTicks);

            Console.ReadLine();


        }
    }
}
