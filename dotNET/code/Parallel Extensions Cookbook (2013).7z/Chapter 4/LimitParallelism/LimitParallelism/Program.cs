﻿using System;
using System.Linq;
using System.Threading;

namespace LimitParallelism
{
    class Program
    {
        private static void Main()
        {
       
            var result = Enumerable.Range(0, 10000).AsParallel()
                          .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                          .WithDegreeOfParallelism(2)
                          .Where(x =>
                              {
                                  Thread.SpinWait(1000000);
                                  return true;
                              })
                          .Select((x, i) => i)
                          .ToArray();

            foreach (var number in result)
                Console.WriteLine("Result: {0}",number);

            Console.ReadLine();
        }
    }
}

