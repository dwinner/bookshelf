﻿using System;
using System.Linq;

namespace HandleExceptions
{
    class Program
    {
        static void Main()
        {
            var employees = new[]
                {
                    new Employee{Id = 1, Title = "Developer", FirstName = "Mark", LastName = "Smith"},
                    new Employee{Id = 2, Title = "Director", FirstName = "Kate", LastName = "Williams"},
                    new Employee{Id = 3, Title = "Manager", FirstName = "Karen", LastName = "Davis"},
                    new Employee{Id = 4, Title = "Developer", FirstName = "Maria", LastName = "Santos"},
                    new Employee{Id = 5, Title = "Developer", FirstName = "Thomas", LastName = "Arnold"},
                    new Employee{Id = 6, Title = "Tester", FirstName = "Marcus", LastName = "Gomez"},
                    new Employee{Id = 7, Title = "Network Engineer", FirstName = "Simon", LastName = "Clarke"},
                    new Employee{Id = 8, Title = "Tester", FirstName = "Karmen", LastName = "Wright"},
                    new Employee{Id = 9, Title = "Manager", FirstName = "William", LastName = "Jacobs"},
                    new Employee{Id = 10, Title = "Network Engineer", FirstName = "Samuel", LastName = "Orwell"},
                    new Employee{Id = 11, Title = "Developer", FirstName = "Tony", LastName = "Meyers"},
                    new Employee{Id = 12, Title = "Developer", FirstName = "Karen", LastName = "Smith"},
                    new Employee{Id = 13, Title = "Tester", FirstName = "Juan", LastName = "Rodriguez"},
                    new Employee{Id = 14, Title = "Developer", FirstName = "Sanjay", LastName = "Bhat"},
                    new Employee{Id = 15, Title = "Manager", FirstName = "Abid", LastName = "Naseem"},
                    new Employee{Id = 16, Title = "Developer", FirstName = "Kevin", LastName = "Strong"}
                };

            var results = employees.AsParallel()
                                   .Select(employee =>
                                       {
                                           if (employee.Id > 15)
                                               throw new InvalidOperationException(
                                                   "Invalid employee Id. Id is greater that 15.");
                                           return employee;
                                       });
            try
            {
                foreach (var employee in results)
                {
                    Console.WriteLine("Id:{0}  Title:{1}  First Name:{2}  Last Name:{3}",
                        employee.Id, employee.Title, employee.FirstName, employee.LastName);
                }
            }
            catch (AggregateException aggregateException)
            {
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    Console.WriteLine("The query threw an exception: {0}", exception.Message);
                }
            }
            Console.ReadLine();
        }
    }

    public class Employee
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
