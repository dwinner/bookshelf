﻿using System;
using System.Linq;

namespace RangeProjection
{
    class Program
    {
        static void Main()
        {
            var numbers = ParallelEnumerable.Range(1, 1000)
                .Where(x => x % 5 != 0)
                .Select(i => i);

            
            foreach (var number in numbers)
            {
                Console.WriteLine("Result: {0}",number);
            }

            Console.ReadLine();

        }
    }
}
