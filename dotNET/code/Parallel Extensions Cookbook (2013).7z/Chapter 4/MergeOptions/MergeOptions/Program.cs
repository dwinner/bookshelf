﻿using System;
using System.Linq;
using System.Threading;

namespace MergeOptions
{
    class Program
    {
        static void Main()
        {

            var numbers = ParallelEnumerable.Range(0, 1000);

            var result = numbers.AsParallel()
                                .WithMergeOptions(ParallelMergeOptions.NotBuffered)
                                .Where(number => number % 5 == 0);

           foreach (var number in result)
            {
               Console.WriteLine("Result: {0}",number);
            }

           Console.ReadLine();
        }
    }
}
