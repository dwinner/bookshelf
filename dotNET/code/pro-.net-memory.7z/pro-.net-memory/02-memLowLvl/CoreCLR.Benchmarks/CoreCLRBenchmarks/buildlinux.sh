dotnet build /p:Configuration=Release 
