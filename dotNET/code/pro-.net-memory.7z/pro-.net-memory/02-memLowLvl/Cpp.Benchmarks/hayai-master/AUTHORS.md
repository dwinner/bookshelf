Hayai was originally created in 2011 by Nick Bruun <nick@bruun.co>.

The following people have contributed to Hayai:

* Nick Bruun <nick@bruun.co>
* Alexander "nevkontakte" <aleks@aradmin.org.ru>
* Bruno Nery
* Vlad Lazarenko
* Mateusz Łoskot <mateusz@loskot.net>
* Philipp Fischbeck
* Sławomir Zborowski

