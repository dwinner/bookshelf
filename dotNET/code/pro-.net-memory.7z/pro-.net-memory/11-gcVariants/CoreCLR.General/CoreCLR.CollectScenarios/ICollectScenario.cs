﻿namespace CoreCLR.CollectScenarios
{
    public interface ICollectScenario
    {
        int Run();
    }
}
