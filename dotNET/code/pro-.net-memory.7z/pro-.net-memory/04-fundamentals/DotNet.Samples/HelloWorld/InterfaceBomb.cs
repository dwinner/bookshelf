﻿using System;

namespace HelloWorld
{
	public interface IInterface0 
	{
		void Method();
	}

	public class Class0  : IInterface0
	{
		public void Method()
		{
			Console.WriteLine("HelloWorld0!");
		}
	}

	public interface IInterface1 
	{
		void Method();
	}

	public class Class1  : IInterface1
	{
		public void Method()
		{
			Console.WriteLine("HelloWorld1!");
		}
	}

	public interface IInterface2 
	{
		void Method();
	}

	public class Class2  : IInterface2
	{
		public void Method()
		{
			Console.WriteLine("HelloWorld2!");
		}
	}

	public interface IInterface3 
	{
		void Method();
	}

	public class Class3  : IInterface3
	{
		public void Method()
		{
			Console.WriteLine("HelloWorld3!");
		}
	}

	public interface IInterface4 
	{
		void Method();
	}

	public class Class4  : IInterface4
	{
		public void Method()
		{
			Console.WriteLine("HelloWorld4!");
		}
	}

	public interface IInterface5 
	{
		void Method();
	}

	public class Class5  : IInterface5
	{
		public void Method()
		{
			Console.WriteLine("HelloWorld5!");
		}
	}

}