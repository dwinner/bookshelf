﻿using System;

namespace JitLeak
{
	public interface IInterface 
	{
		void Method0();
		void Method1();
		void Method2();
		void Method3();
		void Method4();
		void Method5();
		void Method6();
		void Method7();
		void Method8();
		void Method9();
		void Method10();
		void Method11();
		void Method12();
		void Method13();
		void Method14();
		void Method15();
		void Method16();
		void Method17();
		void Method18();
		void Method19();
		void Method20();
		void Method21();
		void Method22();
		void Method23();
		void Method24();
		void Method25();
		void Method26();
		void Method27();
		void Method28();
		void Method29();
		void Method30();
		void Method31();
		void Method32();
		void Method33();
		void Method34();
		void Method35();
		void Method36();
		void Method37();
		void Method38();
		void Method39();
		void Method40();
		void Method41();
		void Method42();
		void Method43();
		void Method44();
		void Method45();
		void Method46();
		void Method47();
		void Method48();
		void Method49();
		void Method50();
		void Method51();
		void Method52();
		void Method53();
		void Method54();
		void Method55();
		void Method56();
		void Method57();
		void Method58();
		void Method59();
	}

	public class Class  : IInterface
	{
		public void Method0()
		{
			Console.WriteLine("HelloWorld0!");
		}
		public void Method1()
		{
			Console.WriteLine("HelloWorld1!");
		}
		public void Method2()
		{
			Console.WriteLine("HelloWorld2!");
		}
		public void Method3()
		{
			Console.WriteLine("HelloWorld3!");
		}
		public void Method4()
		{
			Console.WriteLine("HelloWorld4!");
		}
		public void Method5()
		{
			Console.WriteLine("HelloWorld5!");
		}
		public void Method6()
		{
			Console.WriteLine("HelloWorld6!");
		}
		public void Method7()
		{
			Console.WriteLine("HelloWorld7!");
		}
		public void Method8()
		{
			Console.WriteLine("HelloWorld8!");
		}
		public void Method9()
		{
			Console.WriteLine("HelloWorld9!");
		}
		public void Method10()
		{
			Console.WriteLine("HelloWorld10!");
		}
		public void Method11()
		{
			Console.WriteLine("HelloWorld11!");
		}
		public void Method12()
		{
			Console.WriteLine("HelloWorld12!");
		}
		public void Method13()
		{
			Console.WriteLine("HelloWorld13!");
		}
		public void Method14()
		{
			Console.WriteLine("HelloWorld14!");
		}
		public void Method15()
		{
			Console.WriteLine("HelloWorld15!");
		}
		public void Method16()
		{
			Console.WriteLine("HelloWorld16!");
		}
		public void Method17()
		{
			Console.WriteLine("HelloWorld17!");
		}
		public void Method18()
		{
			Console.WriteLine("HelloWorld18!");
		}
		public void Method19()
		{
			Console.WriteLine("HelloWorld19!");
		}
		public void Method20()
		{
			Console.WriteLine("HelloWorld20!");
		}
		public void Method21()
		{
			Console.WriteLine("HelloWorld21!");
		}
		public void Method22()
		{
			Console.WriteLine("HelloWorld22!");
		}
		public void Method23()
		{
			Console.WriteLine("HelloWorld23!");
		}
		public void Method24()
		{
			Console.WriteLine("HelloWorld24!");
		}
		public void Method25()
		{
			Console.WriteLine("HelloWorld25!");
		}
		public void Method26()
		{
			Console.WriteLine("HelloWorld26!");
		}
		public void Method27()
		{
			Console.WriteLine("HelloWorld27!");
		}
		public void Method28()
		{
			Console.WriteLine("HelloWorld28!");
		}
		public void Method29()
		{
			Console.WriteLine("HelloWorld29!");
		}
		public void Method30()
		{
			Console.WriteLine("HelloWorld30!");
		}
		public void Method31()
		{
			Console.WriteLine("HelloWorld31!");
		}
		public void Method32()
		{
			Console.WriteLine("HelloWorld32!");
		}
		public void Method33()
		{
			Console.WriteLine("HelloWorld33!");
		}
		public void Method34()
		{
			Console.WriteLine("HelloWorld34!");
		}
		public void Method35()
		{
			Console.WriteLine("HelloWorld35!");
		}
		public void Method36()
		{
			Console.WriteLine("HelloWorld36!");
		}
		public void Method37()
		{
			Console.WriteLine("HelloWorld37!");
		}
		public void Method38()
		{
			Console.WriteLine("HelloWorld38!");
		}
		public void Method39()
		{
			Console.WriteLine("HelloWorld39!");
		}
		public void Method40()
		{
			Console.WriteLine("HelloWorld40!");
		}
		public void Method41()
		{
			Console.WriteLine("HelloWorld41!");
		}
		public void Method42()
		{
			Console.WriteLine("HelloWorld42!");
		}
		public void Method43()
		{
			Console.WriteLine("HelloWorld43!");
		}
		public void Method44()
		{
			Console.WriteLine("HelloWorld44!");
		}
		public void Method45()
		{
			Console.WriteLine("HelloWorld45!");
		}
		public void Method46()
		{
			Console.WriteLine("HelloWorld46!");
		}
		public void Method47()
		{
			Console.WriteLine("HelloWorld47!");
		}
		public void Method48()
		{
			Console.WriteLine("HelloWorld48!");
		}
		public void Method49()
		{
			Console.WriteLine("HelloWorld49!");
		}
		public void Method50()
		{
			Console.WriteLine("HelloWorld50!");
		}
		public void Method51()
		{
			Console.WriteLine("HelloWorld51!");
		}
		public void Method52()
		{
			Console.WriteLine("HelloWorld52!");
		}
		public void Method53()
		{
			Console.WriteLine("HelloWorld53!");
		}
		public void Method54()
		{
			Console.WriteLine("HelloWorld54!");
		}
		public void Method55()
		{
			Console.WriteLine("HelloWorld55!");
		}
		public void Method56()
		{
			Console.WriteLine("HelloWorld56!");
		}
		public void Method57()
		{
			Console.WriteLine("HelloWorld57!");
		}
		public void Method58()
		{
			Console.WriteLine("HelloWorld58!");
		}
		public void Method59()
		{
			Console.WriteLine("HelloWorld59!");
		}
	}

}