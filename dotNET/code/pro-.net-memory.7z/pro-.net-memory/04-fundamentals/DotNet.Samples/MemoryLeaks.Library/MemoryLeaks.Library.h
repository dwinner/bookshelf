// MemoryLeaks.Library.h

#pragma once

using namespace System;

namespace MemoryLeaksLibrary {

	public ref class Class1
	{
    public:
        int DoSomething(int size);
	};
}
