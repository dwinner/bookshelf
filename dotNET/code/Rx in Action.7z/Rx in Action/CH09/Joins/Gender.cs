namespace Joins
{
    enum Gender
    {
        Male,
        Female
    }
}