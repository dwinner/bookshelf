namespace Joins
{
    enum OpenDirection
    {
        Entering,
        Leaving
    }
}