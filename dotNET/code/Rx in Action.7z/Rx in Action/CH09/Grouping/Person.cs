namespace Grouping
{
    class Person
    {
        public Gender Gender { get; set; }
        public int Age { get; set; }
    }
}