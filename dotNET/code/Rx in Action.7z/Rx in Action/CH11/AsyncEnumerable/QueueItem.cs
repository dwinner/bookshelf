internal class QueueItem
{
    public int Data { get; set; }
}