﻿namespace FirstRxExample
{
    public class StockTick
    {
        public string QuoteSymbol { get; set; }
        public decimal Price { get; set; }

        //other properties
    }
}