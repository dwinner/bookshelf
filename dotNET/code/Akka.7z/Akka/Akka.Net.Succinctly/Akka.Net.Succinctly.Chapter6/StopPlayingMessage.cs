﻿namespace Akka.Net.Succinctly.Chapter6
{
    public class StopPlayingMessage
    {
    }
}