﻿namespace Akka.Net.Succinctly.Chapter4
{
    public class Add
    {
        public Add(double term1, double term2)
        {
            Term1 = term1;
            Term2 = term2;
        }

        public double Term1;
        public double Term2;
    }
}