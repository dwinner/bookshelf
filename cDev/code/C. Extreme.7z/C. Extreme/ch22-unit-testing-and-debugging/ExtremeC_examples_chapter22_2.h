// File name: ExtremeC_examples_chapter22_2.h
// Description: Declarations of the example 22.2

#ifndef _EXTREME_C_EXAMPLE_22_2_
#define _EXTREME_C_EXAMPLE_22_2_

#define TRUE 1
#define FALSE 0

typedef int bool_t;

bool_t random_boolean();

#endif
