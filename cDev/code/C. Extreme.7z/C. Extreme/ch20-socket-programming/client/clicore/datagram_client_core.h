#ifndef DATAGRAM_CLIENT_CORE_H
#define DATAGRAM_CLIENT_CORE_H

void datagram_client_loop(int conn_sd);

#endif
