#ifndef DATAGRAM_SERVER_CORE_H
#define DATAGRAM_SERVER_CORE_H

void serve_forever(int server_sd);

#endif
