#ifndef STREAM_SERVER_CORE_H
#define STREAM_SERVER_CORE_H

void accept_forever(int server_sd);

#endif
