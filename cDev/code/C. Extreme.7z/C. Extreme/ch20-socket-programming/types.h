#ifndef TYPES_H
#define TYPES_H

#define TRUE 1
#define FALSE 0

typedef int bool_t;

#endif
