// File name: ExtremeC_examples_chapter2_2.c
// Description: A simple progrm that we are going to dump its AST using clang!

int main() {
  int var1 = 1;
  double var2 = 2.5;
  int var3 = var1 + var2;
  return 0;
}
