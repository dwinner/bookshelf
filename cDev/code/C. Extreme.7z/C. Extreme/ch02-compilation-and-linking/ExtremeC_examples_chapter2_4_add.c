// File name: ExtremeC_examples_chapter2_4_add.c
// Description: This file contains the implementation for the function 'add'.

int add(int a, int b) {
  return a + b;
}
