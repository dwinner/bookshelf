// File name: ExtremeC_examples_chapter2_4_defines.h
// Description: This header file contains the definitions for two functions.

#ifndef EXTREMEC_EXAMPLES_CHAPTER_2_4_DEFINES_H
#define EXTREMEC_EXAMPLES_CHAPTER_2_4_DEFINES_H

int add(int, int);
int multiply(int, int);

#endif
