// File name: ExtremeC_examples_chapter2_6_add_1.c
// Description: First implementation for the function **add**

int add(int a, int b, int c, int d) {
  return a + b + c + d;
}
