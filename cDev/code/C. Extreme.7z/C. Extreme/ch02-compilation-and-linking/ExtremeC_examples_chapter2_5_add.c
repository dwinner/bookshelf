// File name: ExtremeC_examples_chapter2_5_add.c
// Description: This file contains the 'main' function and a definition for another function 'add'.

int add(int a, int b, int c, int d) {
  return a + b + c + d;
}
