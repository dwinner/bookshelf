// File name: ExtremeC_examples_chapter2_6_add_2.c
// Description: Second implementation for the function **add**

int add(int a, int b) {
  return a + b;
}
