// File name: ExtremeC_exampels_chapter1_1.c
// Description: Example 1.1

#define ABC 5

int main(int argc, char** argv) {
  int x = 2;
  int y = ABC;
  int z = x + y;
  return 0;
}
