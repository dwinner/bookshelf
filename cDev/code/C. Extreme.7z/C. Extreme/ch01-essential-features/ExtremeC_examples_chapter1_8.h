// File name: ExtremeC_exampels_chapter1_8.c
// Description: Example 1.8

#ifndef EXAMPLE_1_8_H
#define EXAMPLE_1_8_H

void say_hello();
int read_age();

#endif
