// File name: ExtremeC_exampels_chapter4_6.c
// Description: Example 4.6

#include <unistd.h> // Needed for sleep function

int main(int argc, char** argv) {
  // Infinite loop
  while (1) {
    sleep(1); // Sleep 1 second
  };
  return 0;
}
