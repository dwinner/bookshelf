// File name: ExtremeC_exampels_chapter4_1.c
// Description: Example 4.1

int main(int argc, char** argv) {
  return 0;
}
