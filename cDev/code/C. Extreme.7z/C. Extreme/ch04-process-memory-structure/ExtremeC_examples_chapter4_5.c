// File name: ExtremeC_exampels_chapter4_5.c
// Description: Example 4.5

int main(int agrc, char** argv) {
  return 0;
}
