// File name: ExtremeC_exampels_chapter4_3.c
// Description: Example 4.3

int global_var1;
int global_var2;
int global_var3 = 0;

double global_var4 = 4.5;
char global_var5 = 'A';

int main(int argc, char** argv) {
  return 0;
}
