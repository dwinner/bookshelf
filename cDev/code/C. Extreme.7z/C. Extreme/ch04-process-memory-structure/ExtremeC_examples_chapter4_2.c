// File name: ExtremeC_exampels_chapter4_2.c
// Description: Example 4.2

int global_var1;
int global_var2;
int global_var3 = 0;

int main(int argc, char** argv) {
  return 0;
}
