// File name: ExtremeC_exampels_chapter4_4.c
// Description: Example 4.4

int     x = 33;            // 0x00000021
int     y = 0x12153467;
char z[6] = "ABCDE";

int main(int argc, char**argv) {
  return 0;
}
