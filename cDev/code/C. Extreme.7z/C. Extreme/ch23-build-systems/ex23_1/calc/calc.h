// File name: ExtremeC_examples_chapter20_1.h

#ifndef EXTREMEC_EXAMPLES_CHAPTER_20_1_H
#define EXTREMEC_EXAMPLES_CHAPTER_20_1_H

int add(int, int);
int subtract(int, int);
int multiply(int, int);

#endif
