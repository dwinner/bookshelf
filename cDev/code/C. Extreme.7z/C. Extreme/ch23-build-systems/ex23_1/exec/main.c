#include<stdio.h>
#include <calc.h>

int main(int argc, char** argv) {
  printf("Add(3, 4): %d\n", add(3, 4));
  printf("Subtrct(5, 8): %d\n", subtract(5, 8));
  printf("Multiply(2, 9): %d\n", multiply(2, 9));
  return 0;
}
