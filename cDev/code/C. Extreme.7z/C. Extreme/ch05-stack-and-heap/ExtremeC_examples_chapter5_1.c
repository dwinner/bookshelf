// File name: ExtremeC_examples_chapter5_1.c
// Description: Example 5.1

#include <stdio.h>

int main(int argc, char** argv) {
  char arr[4];
  arr[0] = 'A';
  arr[1] = 'B';
  arr[2] = 'C';
  arr[3] = 'D';
  return 0;
}
