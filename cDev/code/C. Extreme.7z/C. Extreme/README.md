


## Extreme C

Kamran Amini <kam.cpp@gmail.com>

**Published by Packt**
### Download a free PDF

 <i>If you have already purchased a print or Kindle version of this book, you can get a DRM-free PDF version at no cost.<br>Simply click on the link to claim your free PDF.</i>
<p align="center"> <a href="https://packt.link/free-ebook/9781789343625">https://packt.link/free-ebook/9781789343625 </a> </p>