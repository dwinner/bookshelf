// File name: ExtremeC_examples_chapter10_1.c
// Description: Simple sleep

#include <unistd.h>

int main(int argc, char** argv) {
  sleep(1);
  return 0;
}
