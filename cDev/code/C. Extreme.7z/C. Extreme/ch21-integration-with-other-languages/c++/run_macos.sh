set -x

DYLD_LIBRARY_PATH=$PWD/.. ./cstack_cpp.out
