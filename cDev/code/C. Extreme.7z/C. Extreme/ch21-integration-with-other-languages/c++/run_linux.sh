set -x

LD_LIBRARY_PATH=$PWD/.. ./cstack_cpp.out
