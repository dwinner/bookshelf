set -x

LD_LIBRARY_PATH=$PWD/.. ./stack.out
