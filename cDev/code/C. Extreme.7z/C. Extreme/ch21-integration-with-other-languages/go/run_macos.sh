set -x

DYLD_LIBRARY_PATH=$PWD/.. ./stack.out
