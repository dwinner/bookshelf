set -x

go build -o stack.out stack.go
