char*f="char *f=%c%s%c;main(){printf(f,34,f,34,10);}%c";
main(){printf(f,34,f,34,10);}
