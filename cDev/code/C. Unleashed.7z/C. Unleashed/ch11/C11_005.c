int GetOrders(ORDER_LINE *OrderArray,
              size_t MaxEntries)
