void PopulateLoadingArray(double Loading[][NUM_GENDERS],
                         size_t MaxAge,
                         size_t NumGenders)
