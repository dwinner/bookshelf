#define MAX_AGE 130
#define NUM_GENDERS 2

double Loading[MAX_AGE][NUM_GENDERS] = {0};
