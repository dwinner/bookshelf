  for(i = 0; i < OUTER; i++)
  {
    for(j = 0; j < INNER; i++)
    {
      total += array[i][j];
    }
  }
