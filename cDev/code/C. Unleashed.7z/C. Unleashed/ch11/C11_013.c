#include <stdlib.h>

  /* ... */

  T *p;
  p = malloc(N * sizeof *p);
  if(p != NULL)
  {
    /* we have our array, and may now use it for storage */
  }
