/* adjmatrix.h */

#ifndef ADJMATRIX_H
#define ADJMATRIX_H

#include "graphprv.h"

extern struct Graph_Spec AdjMatrix_Spec;

#endif
