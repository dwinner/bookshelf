/* topsort.h */

#include "graphs.h"

int TopologicalSort(struct Graph * G, int ** sorted);
