/*
** The proper usage and copyright information for
** this software is covered in DSCRLic.TXT
** This code is Copyright 1999 by Dann Corbit
*/

#define ETYPE_SIGNED_INT
#include "allsort.h"
