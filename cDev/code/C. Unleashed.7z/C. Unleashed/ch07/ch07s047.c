  strcpy(p, q);
