
  /* ... some code ... */

  PRINT(("foo = %s, bar = %d, baz = %f", foo, bar, baz));

  /* ... code continues ... */

