#define PRINT(x) printf x
