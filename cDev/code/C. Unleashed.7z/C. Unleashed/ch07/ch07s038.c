double CalcMetresPerSecond(double miles, double hour)
{
  return miles * 0.447 / hour;
}
