CF_CODE({)
CF_CODE(  int i);
CF_CODE(  for(i = 0; i < 10; i++))
CF_CODE(    F_FOLLOW2("arr[%d] = [%d]\n", i, arr[i]);)
CF_CODE(})
