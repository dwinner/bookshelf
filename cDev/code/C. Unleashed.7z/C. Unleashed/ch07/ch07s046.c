  char *p;
