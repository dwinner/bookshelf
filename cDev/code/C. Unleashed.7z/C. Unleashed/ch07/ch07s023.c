  free(NULL);
