enum { DEBUG = 0 };

if(DEBUG)
  printf(....
