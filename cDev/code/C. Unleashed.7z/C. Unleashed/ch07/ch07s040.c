  assert(fabs(hour) > DBL_MIN);
