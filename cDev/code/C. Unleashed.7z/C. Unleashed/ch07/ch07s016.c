#include <stdio.h>
#include <string.h>
int main(void)
{
  char *s;
  strcpy(s, "Hello world!");
  printf("%s\n", s);
  return 0;
}
