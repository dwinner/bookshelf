#define SWAP(x, y) do{unsigned long tmp;\
                      tmp = x;\
                      x = y;\
                      y = tmp;} while(0)
