  for(i = 0; i < numelems - 1; i++)
