int GetLoginNameFromUser(char buffer[100])
/* ... */
