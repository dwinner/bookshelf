  if(NULL = root->left)
  {
    /* ... */
