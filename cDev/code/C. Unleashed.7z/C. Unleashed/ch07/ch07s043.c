char dummy[sizeof(FOO) == sizeof(BAR) ? 1 : -1];
