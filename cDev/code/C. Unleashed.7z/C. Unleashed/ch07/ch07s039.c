  if(fabs(hour) > DBL_MIN)
  /* ... */
