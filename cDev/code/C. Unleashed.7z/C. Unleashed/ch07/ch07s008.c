  foo = bar(baz);
  if(baz == 9)
    foo = 13.4;
