int foo(char *bar)
{
  assert(bar);
  /* ... */
}
