#ifdef CFOLLOW_ON__
  {
    int i;
    for(i = 0; i < 10; i++)
      F_FOLLOW2("arr[%d] = [%d]\n", i, arr[i]);
  }
#endif
