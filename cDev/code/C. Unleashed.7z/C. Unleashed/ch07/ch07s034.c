#ifndef NDEBUG
  DebugDumpList(&Root);
#endif
