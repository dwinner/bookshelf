int foo(char *bar)
{
  assert(bar != NULL);
  /* ... */
}
