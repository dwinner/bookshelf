#include <stdio.h>

int main(void)
{
  char *s = "string";
  int d = 42;
  double f = 3.14;
  printf("String is %s, int is %d, double is %f\n");
  return 0;
}
