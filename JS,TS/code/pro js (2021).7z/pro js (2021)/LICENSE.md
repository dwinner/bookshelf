The code in this repo is Copyright © 2020 by David Flanagan but is free for
everyone to use. O'Reilly's standard permission notice appears in the
book's preface:

> This book is here to help you get your job done. In general, if
> example code is offered with this book, you may use it in your
> programs and documentation. You do not need to contact us for
> permission unless you’re reproducing a significant portion of the
> code. For example, writing a program that uses several chunks of code
> from this book does not require permission. Selling or distributing
> examples from O’Reilly books does require permission. Answering a
> question by citing this book and quoting example code does not require
> permission. Incorporating a significant amount of example code from
> this book into your product’s documentation does require permission.
